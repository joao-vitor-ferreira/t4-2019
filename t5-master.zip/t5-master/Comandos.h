#ifndef COMANDOS_H
#define COMANDOS_H
#include "Lista.h"
#include "Hash.h"
#include "kdTree.h"
#include "Registrador.h"
#include "GrafoDirecionado.h"

	typedef int (*Equip)(FILE **txt, Item, Item);
	typedef char *((*Object)(Item));

char *funcIn(int argc, char **argv, char *str);
char *concatena(char *str1, char *str2);
void leitura(Hash ha, int argc, char *argv[], char *str, double *svgH, double *svgW, FILE **svgMain, Lista listCir, Lista listRet, Lista listQua, Lista listSem, Lista listHid, Lista listTor, Lista listPessoa, Hash hashCpf_Cep, Hash hashCpf_Quadra, Hash hashCpf_DadosPessoa, Hash hashCep_Quadra, Hash hashCodt_Desc, kdTree kd_quadra, kdTree kd_hid, kdTree kd_sem, kdTree kd_torre, GrafoD grafoDir, registrador regis[10], Lista listCar);
void funcFree(char **a);
char *colocaBarra(char *str);
char *pegaParametro(int argc, char *argv[], char *str);
void writeSvg(FILE **svg, Lista listCir, Lista listRet, Lista listSem, Lista listQua, Lista listTor, Lista listHid, Lista listCar);
char *funcSvgQry(int argc, char **argv);
void leituraEC(int argc, char *argv[], char *arqIn, Hash hashCodt_Desc, Hash hashCep_Quadra);
void leituraPM(int arc, char *argv[], char *arqIn, Lista listPessoa, Lista listQua, Hash hashCpf_Cep, Hash hashCpf_Quadra, Hash hashCpf_DadosPessoa);
void leituraVia(Hash ha, int argc, char *argv[], char *str, double *svgH, double *svgW, FILE **svgMain, Lista listCir, Lista listRet, Lista listQua, Lista listSem, Lista listHid, Lista listTor, Lista listPessoa, Hash hashCpf_Cep, Hash hashCpf_Quadra, Hash hashCpf_DadosPessoa, Hash hashCep_Quadra, Hash hashCodt_Desc, kdTree kd_quadra, kdTree kd_hid, kdTree kd_sem, kdTree kd_torre, GrafoD grafoDir, registrador regis[10], Lista listCar);

#endif