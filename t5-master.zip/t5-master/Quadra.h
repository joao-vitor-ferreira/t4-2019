#ifndef QUADRA_H
#define QUADRA_H
#include "Retangulo.h"
#include "Circulo.h"
#include "Lista.h"
#include "EstabelecimentoComercial.h"

	typedef void *Quadra;

Quadra createQuadra(double x, double y, double width, double height, char *cep);
char *getQuadraCorContorno(Quadra q);
char *getQuadraCorPreenchimento(Quadra q);
void setQuadraCorPreenchimento(Quadra q, char *cor);
void setQuadraCorContorno(Quadra q, char *cor);
void addQuadraEstab(Quadra q, Estab e);
void deleteQuadraEstab(Quadra q, Posic p);
Lista getQuadraListEstab(Quadra q);
char *getQuadraCep(Quadra q);
double getQuadraX(Quadra q);
double getQuadraY(Quadra q);
double getQuadraWidth(Quadra q);
double getQuadraHeight(Quadra q);
int quadraInternaRetangulo(FILE **txt, Quadra q, Retangulo r);
int verificaQuadraInternaRegiaoRet(Quadra q, double x, double y, double w, double h);
int quadraInternaCirculo(FILE **txt, Quadra q, Circulo c);
int comparaQuadra(Quadra q1, char *id);
void freeQuadra(Quadra q);

#endif