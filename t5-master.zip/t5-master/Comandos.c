#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>
#include <limits.h>
#include "Comandos.h"
#include "Retangulo.h"
#include "Circulo.h"
#include "CalculoCirculoRetangulo.h"
#include "Quadra.h"
#include "Semaforo.h"
#include "Torre.h"
#include "Hidrante.h"
#include "Lista.h"
#include "Svg.h"
#include "Vector.h"
#include "Ordenacao.h"
#include "Elemento.h"
#include "Calculo.h"
#include "EstabelecimentoComercial.h"
#include "Hash.h"
#include "Pessoa.h"
#include "GrafoDirecionado.h"
#include "Carro.h"

long extrai_Index(char *idRegistro){
	char *extrai_Index = idRegistro;
	long indexRegistro;

	while(*extrai_Index){ //extrai valor numerico do registro
		if(isdigit(*extrai_Index)){
			indexRegistro = strtol(extrai_Index, &extrai_Index, 10);
		}
		else{
			extrai_Index++;
		}
	}
	return (indexRegistro - 1);
}

double calculaDistancia(double x1, double y1, double x2, double y2){
	double dist = sqrt(pow(x2 - x1, 2) + pow(y2 - y1, 2));
	return dist;
}

void funcFree(char **a){
	if (a == NULL){
		printf("ERRO\n");
	} else{
		free(*a);
		*a = NULL;
	}
}

char *colocaBarra(char *str){
	int log = 0;
	char *str2 = NULL, *str3 = NULL;
	if (str == NULL){
		return NULL;
	}
	if (str[strlen(str)-1] != '/'){
			str3 = (char*)malloc(sizeof(char)*(strlen(str) + 2));
			sprintf(str3, "%s/", str);
			return str3;
	}
	str3 = (char*)malloc(sizeof(char)*(strlen(str) + 1));
	strcpy(str3, str);
	funcFree(&str);
	return str3;
}

char *concatena(char *str1, char *str2){
	char *aux;

	if (str1 == NULL){
		if (str2 == NULL){
			return NULL;
		} else{
			aux = (char*)malloc(sizeof(char)*(strlen(str2) + 1));
			strcpy(aux, str2);
			return aux;
		}
	} else{
		if (str2 == NULL){
			aux = (char*)malloc(sizeof(char)*(strlen(str1) + 1));
			strcpy(aux, str1);
			return aux;
		} else{
			aux = (char*)malloc(sizeof(char)*(strlen(str1) + strlen(str2) +1));
			strcpy(aux, str1);
			strcat(aux, str2);
			return aux;
		}
	}
}

char *pegaParametro(int argc, char *argv[], char *str){
	int i, j, k;
	char *ret;
	for (i = 1; i < argc; i++){
		if (strcmp(str, argv[i]) == 0){
			if (strcmp(str, "-f") == 0){
				k=0;
				j=strlen(argv[i+1]) - 1;
				while(j>=0){
					if (argv[i+1][j] == '/')	
						break;
					j--;
					k++;
				}
				ret = (char*)malloc(sizeof(char)*(k + 1));
				ret[k]='\0';
				k--;
				j = strlen(argv[i+1]) - 1;
				while(k>=0){
					if (argv[i+1][j] == '/')
						break;
					ret[k] = argv[i+1][j];
					j--;
					k--;
				}
				return ret;
			} else{
				ret = (char *)malloc(sizeof(char)*(strlen(argv[i + 1]) + 1));
				strcpy(ret, argv[i + 1]);
				return ret;
			}
		}
	}
	return NULL;
}

char *funcTxt(int argc, char **argv){
	int i;
	char *aux2 = NULL, *aux3 = NULL, *aux4 = NULL;
	aux4 = pegaParametro(argc, argv, "-o");
	aux2 = (char*)malloc(sizeof(char)*(strlen(aux4) + 1));
	strcpy(aux2, aux4);
	funcFree(&aux4);
	aux2 = colocaBarra(aux2);
	aux4 = pegaParametro(argc, argv, "-f");
	aux3 = concatena(aux2, aux4);
	funcFree(&aux4);
	funcFree(&aux2);
	i = strlen(aux3);
	aux3[i - 1] = 't';
	aux3[i - 2] = 'x';
	aux3[i - 3] = 't';
	return aux3;
}

char *funcIn(int argc, char **argv, char *str){
	char *aux3 = NULL, *arqIn = NULL, *aux2 = NULL, *aux = NULL;
	aux3 = pegaParametro(argc, argv, "-e");
	if (aux3 != NULL){
		aux3 = colocaBarra(aux3);
		aux2 = pegaParametro(argc, argv, str);
		if (aux2 == NULL)
			return NULL;
		arqIn = concatena(aux3, aux2);
		funcFree(&aux2);
		funcFree(&aux3);
	} else{
		arqIn = pegaParametro(argc, argv, str);
	}
	return arqIn;
}

Posic searchObjCep(Lista list, char *cep, Object func){
	int i;
	Posic p1;
	p1 = getFirst(list);
	i = length(list);
	while(i>0){
		if (strcmp(cep, func(getObjt(p1))) == 0){
			return p1;
		}
		p1 = getNext(p1);
		i--;
	}
	return NULL;
}

Posic searchObjId(Lista listCir, Lista listRet, int id){
	Posic p1 = NULL;
	int var;
	Retangulo r1 = NULL;
	Circulo c1 = NULL;
	p1 = getFirst(listRet);
	r1 = getObjt(p1);
	var = (int)length(listRet);
	while(var>0){
		if (getRetanguloId(r1) == id){
			return p1;
		}
		p1 = getNext(p1);
		if (p1 != NULL)
			r1 = getObjt(p1);
		var--;
	}
	p1 = getFirst(listCir);
	c1 = getObjt(p1);
	var = length(listCir);
	while(var>0){
		if (getCirculoId(c1) == id){
			return p1;
		}
		p1 = getNext(p1);
		if (p1 != NULL)
			c1 = getObjt(p1);
		var--;
	}
	return NULL;
}

int typeObj(Lista listCir, Lista listRet, int id){
	Posic p1 = NULL;
	int var;
	Retangulo r1 = NULL;
	Circulo c1 = NULL;
	p1 = getFirst(listRet);
	r1 = getObjt(p1);
	var = (int)length(listRet);
	while(var>0){
		if (getRetanguloId(r1) == id){
			return 0;
		}
		p1 = getNext(p1);
		if (p1 != NULL)
			r1 = getObjt(p1);
		var--;
	}
	p1 = getFirst(listCir);
	c1 = getObjt(p1);
	var = length(listCir);
	while(var>0){
		if (getCirculoId(c1) == id){
			return 1;
		}
		p1 = getNext(p1);
		if (p1 != NULL)
			c1 = getObjt(p1);
		var--;
	}
	return -1;
}

double distanciaCdm(Lista listCir, Lista listRet, int i, int j){
	Posic p1 = NULL, p2 = NULL;
	int tipo1, tipo2;
	double value;
	Retangulo r1 = NULL, r2 = NULL;
	Circulo c1 = NULL, c2 = NULL;
	p1 = (Posic)searchObjId(listCir, listRet, i);
	if (p1 == NULL)
		p1 = searchObjId(listCir, listRet, i);
	p2 = searchObjId(listCir, listRet, j);
	if (p2 == NULL)
		p2 = searchObjId(listCir, listRet, j);
	tipo1 = typeObj(listCir, listRet, i);
	tipo2 = typeObj(listCir, listRet, j);
	if (tipo1 == 0){
		if (tipo2 == 0){
			r1 = (Retangulo)getObjt(p1);
			r2 = (Retangulo)getObjt(p2);
			value = dcmRetanguloRetangulo(r1, r2);
		} else{
			r1 = (Retangulo)getObjt(p1);
			c1 = (Circulo)getObjt(p2);
			value = dcmCirculoRetangulo(c1, r1);
		}
	} else{
		if (tipo2 == 0){
			c1 = (Circulo)getObjt(p1);
			r1 = (Retangulo)getObjt(p2);
			value = dcmCirculoRetangulo(c1, r1);
		} else{
			c1 = (Circulo)getObjt(p1);
			c2 = (Circulo)getObjt(p2);
			value = dcmCirculoCirculo(c1, c2);
		}
	}
	return value;
}

char *funcSvg(int argc, char **argv, char *str){
	int i;
	char *aux = NULL, *strdir = NULL, *aux2 = NULL, *aux3 = NULL, *aux4 = NULL;
	aux3 = pegaParametro(argc, argv, "-o");
	aux4 = pegaParametro(argc, argv, "-f");
	aux2 = (char*)malloc(sizeof(char)*(strlen(aux4)));
	strdir = (char*)malloc(sizeof(char)*(strlen(aux3) + 1));
	strcpy(strdir, aux3);
	strdir = colocaBarra(strdir);
	aux = (char*)malloc(sizeof(char)*(strlen(aux4) + strlen(str) + strlen(strdir) + 2));
	strcpy(aux, strdir);
	funcFree(&strdir);
	for (i = 0; i<(strlen(aux4) - 4); i++){
			aux2[i] = aux4[i];
	}
	aux2[i] = '\0';
	strcat(aux, aux2);
	funcFree(&aux3);
	funcFree(&aux4);
	funcFree(&strdir);
	funcFree(&aux2);
	strcat(aux, "-");
	strcat(aux, str);
	strcat(aux, ".svg");
	return aux;
}

int countQry(char *str){
	int a, ret = 0;
	for (a=strlen(str)-1; a>=0; a--){
		if (str[a] != '/')
			ret++;
		else
			break;
	}
	return ret;
}

int barraQry(char *str){
	int a, ret= -1;
	for (a=strlen(str)-1; a>=0; a--){
		if (str[a] == '/'){
			ret = a;
			break;
		}
	}
	return ret;
}

char *funcSvgQry(int argc, char **argv){
	char *aux, *qry, *str;
	int a, b;
	qry = pegaParametro(argc, argv, "-q");
	aux = (char*)malloc(sizeof(char)*(countQry(qry) -3));
	b = barraQry(qry);
	if (b != -1)
		b += 1;
	else
		b = 0;
	for (a = 0; a<countQry(qry); a++){
		if (qry[b] == '.')
			break;
		aux[a] = qry[b];
		b++;
	}
	funcFree(&qry);
	aux[a] = '\0';
	str = funcSvg(argc, argv, aux);
	funcFree(&aux);
	return str;
}

void writeSvg(FILE **svg, Lista listCir, Lista listRet, Lista listSem, Lista listQua, Lista listTor, Lista listHid, Lista listCar){
	printSvgList(&(*svg), listRet, printSvgRetangulo);
	printSvgList(&(*svg), listQua, printSvgQuadra);
	printSvgList(&(*svg), listTor, printSvgTorre);
	printSvgList(&(*svg), listSem, printSvgSemaforo);
	printSvgList(&(*svg), listHid, printSvgHidrante);
	printSvgList(&(*svg), listCir, printSvgCirculo);
	printSvgList(&(*svg), listCar, printSvgCarro);
}

void cmpRet(Retangulo r1, double *xma, double *xme, double *yma, double *yme){
	if (*xme < 0)
		*xme = getRetanguloX(r1);
	if (*yme < 0)
		*yme = getRetanguloY(r1);
	if (getRetanguloX(r1) < *xme)
		*xme = getRetanguloX(r1);
	if (getRetanguloY(r1) < *yme)
		*yme = getRetanguloY(r1);
	if ((getRetanguloX(r1) + getRetanguloWidth(r1)) > *xma)
		*xma = getRetanguloX(r1) + getRetanguloWidth(r1);
	if ((getRetanguloY(r1) + getRetanguloHeight(r1)) > *yma)
		*yma = getRetanguloY(r1) + getRetanguloHeight(r1);
}

void cmpCir(Circulo c1, double *xma, double *xme, double *yma, double *yme){
	if (*xme < 0)
		*xme = getCirculoX(c1) - getCirculoRaio(c1);
	if (*yme < 0)
		*yme = getCirculoY(c1) - getCirculoRaio(c1);
	if ((getCirculoX(c1) - getCirculoRaio(c1)) < *xme)
		*xme = (getCirculoX(c1) - getCirculoRaio(c1));
	if ((getCirculoY(c1) - getCirculoRaio(c1)) < *yme)
		*yme = getCirculoY(c1) - getCirculoRaio(c1);
	if ((getCirculoX(c1) + getCirculoRaio(c1)) > *xma)
		*xma = getCirculoX(c1) + getCirculoRaio(c1);
	if ((getCirculoY(c1) + getCirculoRaio(c1)) > *yma)
		*yma = getCirculoY(c1) + getCirculoRaio(c1);
}
/* se o elemento de id id estiver na lista, retorno = 1, se não, retorno = 0*/

void removeListCirLeak(Lista listCir){
	Posic p1 = NULL;
	Circulo c1 = NULL;
	char *str = NULL;
	int var;
	p1 = getFirst(listCir);
	c1 = getObjt(p1);
	var = length(listCir);
	while(var > 0){
		str = getCirculoCorPreenchimento(c1);
		funcFree(&str);
		str = getCirculoCorContorno(c1);
		funcFree(&str);
		var--;
	}

}

void consultaQ(FILE *txt, Item item, Lista list, Equip func){
	Posic p1;
	int i;
	p1 = getFirst(list);
	i = length(list);
	while(i>0){
		func(&txt, getObjt(p1), item);
		i--;
		p1 = getNext(p1);
	}
}

int cmpQuadra(Quadra q1, double x, double y, double width, double height){
	if (getQuadraX(q1) == x){
		if (getQuadraY(q1) == y){
			if (getQuadraWidth(q1) == width){
				if (getQuadraHeight(q1) == height)
					return 1;
			}
		}
	}
	return 0;
}

void svgCmpCirculo(double *svgH, double *svgW, double x, double y, double raio){
	if ((x+raio) > *svgW)
		*svgW = x+raio;
	if ((y+raio) > *svgH)
		*svgH = y+raio;
}

void svgCmpRetangulo(double *svgH, double *svgW, double x, double y, double height, double width){
	if ((x + width) > *svgW)
		*svgW = x + width;
	if ((y+height) > *svgH)
		*svgH = y + height;
}

typedef struct{ //está tambem em "Estab.c"
	char *cnpj;
	char *tipo;
	char *cep;
	char *face; 
	int num;
	char *nome;
} estab;

double getEstabPosicX(Estab e, Quadra q){ //estaria em Estab.h mas causaria conflito de "cross-reference" nos headers
	estab *newEstab = e;
	if(strcmp(getEstabFace(e), "N") == 0 || strcmp(getEstabFace(e), "S") == 0){
		return (getQuadraX(q) + (getQuadraWidth(q)/2)	);
	}
	else if (strcmp(getEstabFace(e), "L") == 0) {
		return (getQuadraX(q));
	}
	else {
		return (getQuadraX(q) + getQuadraWidth(q));
	}
}

double getEstabPosicY(Estab e, Quadra q){ //estaria em Estab.h mas causaria conflito de "cross-reference" nos headers
	estab *newEstab = e;
	if(strcmp(getEstabFace(e), "N") == 0) {
		return (getQuadraY(q) + getQuadraHeight(q));
	}
	else if (strcmp(getEstabFace(e), "S") == 0) {
		return (getQuadraY(q));
	}
	else {
		return (getQuadraY(q) + (getQuadraHeight(q)/2)  );
	}
}

Elemento menorPraCima(Vector vet, int atual, char letra){
	double dist;
	int count = 0, p = atual + 1;
	Elemento e1, e2;
	if (letra == 'x'){
		e1 = getObjVector(vet, atual);
		while(1){
			e2 = getObjVector(vet, p);
			if (getElementoX(e1) != getElementoY(e2))
				break;
			count++;
			p++;
			if (p > getSizeVector(vet))
				break;
		}
		p = atual + 1;
		e2 = getObjVector(vet, p);
		dist = distanciaEntrePontos(getElementoX(e1), getElementoY(e1), getElementoX(e2), getElementoY(e2));
		while(count>=2){
			e2 = getObjVector(vet, p);

		}
	}
}

Elemento menorPraBaixo(Vector vet, int atual, char letra){
	Elemento e1, e2, e3, menor;
	int p;
	double dist, peq;
	e1 = getObjVector(vet, atual);
	e2 = getObjVector(vet, atual - 1);
	peq = distanciaEntrePontos(getElementoX(e1), getElementoY(e1), getElementoX(e2), getElementoY(e2));
	menor = e2;
	if (letra == 'x'){
		if ((atual - 2) >= 1){
			p = atual - 2;
			e2 = getObjVector(vet, p);
			while(getElementoX(e1) == getElementoX(e2)){
				dist = distanciaEntrePontos(getElementoX(e1), getElementoY(e1), getElementoX(e2), getElementoY(e2));
				if (dist < peq){
					peq = dist;
					menor = e2;
				}
				p--;
				if (p >= 1)
					break;
				e2 = getObjVector(vet, p);
			}
		}
		return menor;
	}
	if ((atual - 2) >= 1){
		p = atual - 2;
		e2 = getObjVector(vet, p);
		while(getElementoY(e1) == getElementoY(e2)){
			dist = distanciaEntrePontos(getElementoX(e1), getElementoY(e1), getElementoX(e2), getElementoY(e2));
			if (dist < peq){
				peq = dist;
				menor = e2;
			}
			p--;
			if (p >= 1)
				break;
			e2 = getObjVector(vet, p);
		}
	}
	return menor;
}


double elementCloser(double x, double y, Vector vet, Elemento *e, char letra){
	int indice, n;
	double dist, la;
	Elemento e1, e2, e3;
	for (n=1; n<=getSizeVector(vet); n++){
		e1 = getObjVector(vet, n);
		if (x == getElementoX(e1)){
			if (y == getElementoY(e1)){
				indice = n;
				break;
			}
		}
	}
	
	e2 = menorPraCima(vet, indice, letra);
	e3 = menorPraBaixo(vet, indice, letra);
	distanciaEntrePontos(getElementoX(e1), getElementoY(e1), getElementoX(e2), getElementoY(e2));
	dist = 
	la = distanciaEntrePontos(getElementoX(e1), getElementoY(e1), getElementoX(e3), getElementoY(e3));
	if (dist < la){
		*e = e2;
		return dist;
	}else{
		*e = e3;
		return la;
	}
}

Hidrante cmdHmpe(Quadra q1, char *face, int num){
	Hidrante h1;
	char *str;
	str = (char*)malloc(sizeof(char)*(strlen("coco")+ 1));
	strcpy(str, "coco");
	if (strcmp(face, "N") ==0){
		h1 = createHidrante(getQuadraX(q1) + num/10, getQuadraY(q1), str);
	} else if (strcmp(face, "S")==0){
		h1 = createHidrante(getQuadraX(q1) + num/10, getQuadraY(q1) + getQuadraHeight(q1), str);
	} else if (strcmp(face, "L")==0){
		h1 = createHidrante(getQuadraX(q1) + getQuadraWidth(q1), getQuadraY(q1) + num/10, str) ;
	} else if (strcmp(face, "O")==0){
		h1 = createHidrante(getQuadraX(q1), getQuadraY(q1) + num/10, str);
	}
	return h1;
}

void removerInternoRet(FILE *txt, Lista list, Retangulo ret, Equip cmp){
	Posic p, paux;
	int var;
	Item i;
	p = getFirst(list);
	while(1){
		if (p == NULL)
			break;
		i = getObjt(p);
		var = cmp(&txt, i, ret);
		if (var == 1){
			paux = getNext(p);
			remover(list, p);
		}
		if (paux == NULL)
			p = getNext(p);
		else{
			p = paux;
			paux = NULL;
		}
	}

}

Quadra searchQuadraCep(Lista list, char *cep){
	int i;
	Posic p;
	Quadra q1 = NULL;
	p = getFirst(list);
	for (i = 0; i<length(list); i++){
		q1 = getObjt(p);
		if (strcmp(cep, getQuadraCep(q1)) == 0){
			return q1;
		}
		p = getNext(p);
	}
	return NULL;
}

Posic searchEstabCnpj(Lista list, char *cnpj){
	int i, j;
	Posic p, p2;
	Estab estab1 = NULL;
	Quadra q1 = NULL;
	Lista l1;
	p = getFirst(list);
	for (i = 0; i<length(list); i++){
		q1 = getObjt(p);
		l1 = getQuadraListEstab(q1);
		p2 = getFirst(l1);
		for (j = 0; j<length(l1); j++){
			if (p2 == NULL)
				break;
			estab1 = getObjt(p2);
			if (strcmp(getEstabCNPJ(estab1), cnpj) == 0){
				return p2;
			}
			p2 = getNext(p2);
		}
		p = getNext(p);
	}
	return NULL;
}

void posicaoPessoa(Lista list, Endereco e, double *x, double *y){
	Posic p1;
	Quadra q1;
	p1 = getFirst(list);
	int i;
	for (i=0; i<length(list); i++){
		q1 = getObjt(p1);
		if (strcmp(getEnderecoCep(e), getQuadraCep(q1)) == 0){
			if(strcmp(getEnderecoFace(e), "N") == 0){
				*x = getQuadraX(q1) + 20.0;
				*y = getQuadraY(q1);
			} else if(strcmp(getEnderecoFace(e), "S") == 0){
				*x = getQuadraX(q1) + 20.0;
				*y = getQuadraY(q1) + getQuadraHeight(q1) - 10;
			} else if(strcmp(getEnderecoFace(e), "L") == 0){
				*x = getQuadraX(q1) + getQuadraWidth(q1) - 5;
				*y = getQuadraY(q1) + 20;
			} else{
				*x = getQuadraX(q1) + 5;
				*y = getQuadraY(q1) + 20;
			}
		}
		p1 = getNext(p1);
	}
}

void leitura(Hash ha, int argc, char *argv[], char *arqIn, double *svgH, double *svgW, FILE **svgMain, Lista listCir, Lista listRet, Lista listQua, Lista listSem, Lista listHid, Lista listTor, Lista listPessoa, Hash hashCpf_Cep, Hash hashCpf_Quadra, Hash hashCpf_DadosPessoa, Hash hashCep_Quadra, Hash hashCodt_Desc, kdTree kd_quadra, kdTree kd_hid, kdTree kd_sem, kdTree kd_torre, GrafoD grafoDir, registrador regis[10], Lista listCar){
	Posic p1 = NULL, p2 = NULL;
	FILE *entrada = NULL, *txt = NULL, *svg = NULL, *lixo = NULL;
	Circulo c1 = NULL, c2 = NULL;
	Retangulo r1 = NULL, r2 = NULL;
	Quadra q1 = NULL, q2 = NULL;
	Semaforo s1 = NULL;
	Torre t1 = NULL;
	Hidrante h1 = NULL;
	Estab estab1 = NULL;
	Pessoa pessoa1 = NULL;
	Endereco end1 = NULL;
	Carro car1 = NULL;
	HashElement elementCpf_Quadra, elementCpf_DadosPessoa, elementCep_Quadra, elementCodt_Desc;
	char *line = NULL, *word = NULL, *cor1 = NULL, *cor2 = NULL, 
	*aux = NULL, *aux2 = NULL, *aux3 = NULL, *suf = NULL, *cep = NULL, *testCEP = NULL, *cpf = NULL, *cnpj = NULL, *codt = NULL, *tipo = NULL, *face = NULL, *complm = NULL,
	*corQP = NULL, *corQC = NULL, *corHP = NULL, *corHC = NULL, *corTP = NULL, *corTC = NULL, *corSP = NULL, *corSC = NULL;
	int i, j, var, tipo1, tipo2, id1, id2, num;
	double raio, x, y, height, width, value, xme, yme, xma, yma;
	tipo = (char*)malloc(sizeof(char)*20);
	complm = (char*)malloc(sizeof(char)*20);
	face = (char*)malloc(sizeof(char)*20);
	cep = (char*)malloc(sizeof(char)*20);
	cpf = (char*)malloc(sizeof(char)*20);
	cnpj = (char*)malloc(sizeof(char)*20);
	codt = (char*)malloc(sizeof(char)*20);
	line = (char*)malloc(sizeof(char)*200);
	word =(char*)malloc(sizeof(char)*30);
	cor1 = (char*)malloc(sizeof(char)*20);
	cor2 = (char*)malloc(sizeof(char)*20);
	suf = (char*)malloc(sizeof(char)*40);
	corQP = (char*)malloc(sizeof(char)*20);
	corQC = (char*)malloc(sizeof(char)*20);
	corHP = (char*)malloc(sizeof(char)*20);
	corHC = (char*)malloc(sizeof(char)*20);
	corSP = (char*)malloc(sizeof(char)*20);
	corSC = (char*)malloc(sizeof(char)*20);
	corTP = (char*)malloc(sizeof(char)*20);
	corTC = (char*)malloc(sizeof(char)*20);
	entrada = fopen(arqIn, "r");
	num= 0;
	if(entrada == NULL){
		printf("Error opening file.");
		return;
	}
	while(!feof(entrada)){
		fscanf(entrada, "%[^\n]\n", line);
		sscanf(line, "%s", word);
		if (strcmp(word, "c") == 0){
			sscanf(line, "%s %d %s %s %lf %lf %lf", word, &i, cor1, cor2, &raio, &x, &y);
			aux = (char*)malloc(sizeof(char)*(strlen(cor1) + 1));
			aux2 = (char*)malloc(sizeof(char)*(strlen(cor2) + 1));
			strcpy(aux, cor1);
			strcpy(aux2, cor2);
			c1 = creatCirculo(i, raio, x, y, aux2, aux);
			insert(listCir, (Item)c1);
			if ((getCirculoX(c1) + getCirculoRaio(c1)) > *svgW){
				*svgW = getCirculoX(c1) + getCirculoRaio(c1);
			}
			if ((getCirculoY(c1) + getCirculoRaio(c1)) > *svgH){
				*svgH = getCirculoY(c1) + getCirculoRaio(c1);
			}
		} else if (strcmp(word, "r") == 0){
			sscanf(line, "%s %d %s %s %lf %lf %lf %lf", word, &i, cor1, cor2, &width, &height, &x, &y);
			aux = (char*)malloc(sizeof(char)*(strlen(cor1) + 1));
			aux2 = (char*)malloc(sizeof(char)*(strlen(cor2) + 1));
			strcpy(aux, cor1);
			strcpy(aux2, cor2);
			r1 = creatRetangulo(i, width, height, x, y, aux2, aux);
			insert(listRet, (Item)r1);
			if ((getRetanguloX(r1) + getRetanguloWidth(r1)) > *svgW){
				*svgW = getRetanguloX(r1) + getRetanguloWidth(r1);
			}
			if ((getRetanguloY(r1) + getRetanguloHeight(r1)) > *svgH){
				*svgH = getRetanguloY(r1) + getRetanguloHeight(r1);
			}
		}else if(strcmp(word, "cq") == 0){
			sscanf(line, "%s %s %s", word, corQC, corQP);
		}else if(strcmp(word, "ct") == 0){
			sscanf(line, "%s %s %s", word, corTC, corTP);
		}else if(strcmp(word, "ch") == 0){
			sscanf(line, "%s %s %s", word, corHC, corHP);
		}else if(strcmp(word, "cs") == 0){
			sscanf(line, "%s %s %s", word, corSC, corSP);
		}else if(strcmp(word, "q") == 0){
			sscanf(line, "%s %s %lf %lf %lf %lf", word, cep, &x, &y, &width, &height);
			aux = (char*)malloc(sizeof(char)*(strlen(cep) + 1));
			strcpy(aux, cep);
			testCEP = (char*)malloc(sizeof(char)*(strlen(cep) + 1));
			strcpy(testCEP, cep);
			q1 = (Quadra)createQuadra(x, y, width, height, aux);
			aux = (char*)malloc(sizeof(char)*(strlen(corQP) + 1));
			strcpy(aux, corQP);
			setQuadraCorPreenchimento(q1, aux);
			aux = (char*)malloc(sizeof(char)*(strlen(corQC) + 1));
			strcpy(aux, corQC);
			setQuadraCorContorno(q1, aux);
			insert(listQua, (Item)q1);
				*svgW = x + width;
			if ((y + height) > *svgH)
				*svgH = y + height;
			addHash(ha, q1, getQuadraCep(q1));
			addHash(hashCep_Quadra, q1, getQuadraCep(q1));
			inserirItemKdTree(kd_quadra, q1, x, y);
		}else if(strcmp(word, "s") == 0){
			sscanf(line, "%s %s %lf %lf", word, cep, &x, &y);
			aux = (char*)malloc(sizeof(char)*(strlen(cep) + 1));
			strcpy(aux, cep);
			s1 = createSemaforo(x, y, aux);
			aux = (char*)malloc(sizeof(char)*(strlen(corSP) + 1));
			strcpy(aux, corSP);
			setSemaforoCorPreenchimento(s1, aux);
			aux = (char*)malloc(sizeof(char)*(strlen(corSC) + 1));
			strcpy(aux, corSC);
			setSemaforoCorContorno(s1, aux);
			insert(listSem, (Item)s1);
			inserirItemKdTree(kd_sem, s1, x, y);
			if (x > *svgW)
				*svgW = x;
			if (y > *svgH)
				*svgH = y;
		}else if(strcmp(word, "t") == 0){
			sscanf(line, "%s %s %lf %lf", word, cep, &x, &y);
			aux = (char*)malloc(sizeof(char)*(strlen(cep) + 1));
			strcpy(aux, cep);
			t1 = createTorre(x, y, aux);
			aux = (char*)malloc(sizeof(char)*(strlen(corTP) + 1));
			strcpy(aux, corTP);
			setTorreCorPreenchimento(t1, aux);
			aux = (char*)malloc(sizeof(char)*(strlen(corTC) + 1));
			strcpy(aux, corTC);
			setTorreCorContorno(t1, aux);
			insert(listTor, (Item)t1);
			inserirItemKdTree(kd_torre, t1, x, y);
			if (x > *svgW)
				*svgW = x;
			if (y > *svgH)
				*svgH = y;
		}else if(strcmp(word, "h") == 0){
			sscanf(line, "%s %s %lf %lf", word, cep, &x, &y);
			aux = (char*)malloc(sizeof(char)*(strlen(cep) + 1));
			strcpy(aux, cep);
			h1 = createHidrante(x, y, aux);
			aux = (char*)malloc(sizeof(char)*(strlen(corHP) + 1));
			strcpy(aux, corHP);
			setHidranteCorPreenchimento(h1, aux);
			aux = (char*)malloc(sizeof(char)*(strlen(corHC) + 1));
			strcpy(aux, corHC);
			setHidranteCorContorno(h1, aux);
			insert(listHid, (Item)h1);
			inserirItemKdTree(kd_hid, h1, x, y);
			if (x > *svgW)
				*svgW = x;
			if (y > *svgH)
				*svgH = y;
		} else if (strcmp(word, "i") == 0){
			sscanf(line, "%s %d %lf %lf", word, &j, &x, &y);
			p1 = searchObjId(listCir, listRet, j);
			i = typeObj(listCir, listRet, j);
			if (i == 0){
				r1 = (Retangulo)getObjt(p1);
				if (r1 != NULL)
					var = pontoInternoRetangulo(r1, x, y);
				else
					var = -1;
			} else{
				c1 = (Circulo)getObjt(p1);
				if (c1 != NULL)
					var = pontoInternoCirculo(c1, x, y);
				else
					var = -1;
			}
			aux = funcTxt(argc, argv);
			if (txt == NULL){
				txt = fopen(aux, "w");
			}
			funcFree(&aux);
			if (var == 0){
				fprintf(txt, "%s\nNÃO\n", line);
			} else{
				fprintf(txt, "%s\nSIM\n", line);
			}
		} else if (strcmp(word, "o") == 0){
			xma = 0.0;
			yma = 0.0;
			xme = -1.0;
			yme = -1.0;
			sscanf(line, "%s %d %d", word, &i, &j);
			p1 = searchObjId(listCir, listRet, i);
			if (p1 == NULL)
				p1 = searchObjId(listCir, listRet, i);
			tipo1 = typeObj(listCir, listRet, i);
			p2 = searchObjId(listCir, listRet, j);
			if (p2 == NULL)
				p2 = searchObjId(listCir, listRet, j);
			tipo2 = typeObj(listCir, listRet, j);
			if (tipo1 == 0){
				if (tipo2 == 0){
					r1 = (Retangulo)getObjt(p1);
					r2 = (Retangulo)getObjt(p2);
					var = sobreposicaoRetanguloRetangulo(r1, r2);
					if (var == 1){
						cmpRet(r1, &xma, &xme, &yma, &yme);
						cmpRet(r2, &xma, &xme, &yma, &yme);
					}
				} else{
					r1 = (Retangulo)getObjt(p1);
					c1 = (Circulo)getObjt(p2);
					var = sobreposicaoCirculoRetangulo(c1, r1);
					if (var == 1){
						cmpRet(r1, &xma, &xme, &yma, &yme);
						cmpCir(c1, &xma, &xme, &yma, &yme);
					}
				}
			} else{
				if (tipo2 == 0){
					r1 = (Retangulo)getObjt(p2);
					c1 = (Circulo)getObjt(p1);
					var = sobreposicaoCirculoRetangulo(c1, r1);
					if (var == 1){
						cmpRet(r1, &xma, &xme, &yma, &yme);
						cmpCir(c1, &xma, &xme, &yma, &yme);
					}
				} else{
					c1 = (Circulo)getObjt(p1);
					c2 = (Circulo)getObjt(p2);
					var  = sobreposicaoCirculoCirculo(c1, c2);
					if (var == 1){
						cmpCir(c1, &xma, &xme, &yma, &yme);
						cmpCir(c2, &xma, &xme, &yma, &yme);
					}
				}
			}
			aux = funcTxt(argc, argv);
			if (txt == NULL){
				txt = fopen(aux, "w");
			}
			funcFree(&aux);
			if (var == 0){
				fprintf(txt, "%s\nNÃO\n", line);
			} else{
				fprintf(txt, "%s\nSIM\n", line);
				fprintf(*svgMain, "<rect x=\"%f\" y=\"%f\" width=\"%f\" height=\"%f\" fill=\"white\" stroke=\"purple\" stroke-width=\"4\" fill-opacity = \"0.000\" stroke-dasharray = \"5,10,2\"/>\n", xme, yme, (xma - xme), (yma - yme));
			}
			if ((xme + (xma -xme)) > *svgW)
				*svgH = xme + (xma -xme);
			if ((yme + (yma - yme)) > *svgH)
				*svgH = yme + (yma - yme);
		} else if (strcmp(word, "d") == 0){
			sscanf(line, "%s %d %d", word, &i, &j);
			value = distanciaCdm(listCir, listRet, i, j);
			if (txt == NULL){
				aux = funcTxt(argc, argv);
				txt = fopen(aux, "w");
				funcFree(&aux);
			}
			fprintf(txt, "%s\n%.10f\n", line, value);
		} else if (strcmp(word, "nx") == 0){
			sscanf(line, "%s %d", word, &i);
		}else if (strcmp(word, "a") == 0){
			sscanf(line, "%s %d %s", word, &i, suf);
			aux = funcSvg(argc, argv, suf);
			svg = fopen(aux, "w");
			funcFree(&aux);
			fprintf(svg, "<svg height = \"%f\" width = \"%f\">\n", *svgH, *svgW);
			tipo1 = typeObj(listCir, listRet, i);
			if (tipo1 == 0){
				p1 = searchObjId(listCir, listRet, i);
				r1 = getObjt(p1);
				printSvgRetangulo(&svg, r1);
				id1 = getRetanguloId(r1);
				j = length(listRet);
				if (j>0){
					p1 = getFirst(listRet);
					while(j>0){
						r2 = getObjt(p1);
						if (getRetanguloId(r2) != getRetanguloId(r1)){
							printSvgRetangulo(&svg, r2);
							printSvgLine(&svg, (getRetanguloX(r1)+getRetanguloWidth(r1)/2), (getRetanguloY(r1)+getRetanguloHeight(r1)/2), (getRetanguloX(r2)+getRetanguloWidth(r2)/2), (getRetanguloY(r2)+getRetanguloHeight(r2)/2));
						}
						p1 = getNext(p1);
						j--;
					}
					j = length(listCir);
					p1 = getFirst(listCir);
					while(j>0){
						c2 = getObjt(p1);
						printSvgCirculo(&svg, c2);
						printSvgLine(&svg, getCirculoX(c2), getCirculoY(c2), (getRetanguloX(r1)+getRetanguloWidth(r1)/2), (getRetanguloY(r1)+getRetanguloHeight(r1)/2));
						p1 = getNext(p1);
						j--;
					}
				}
			} else if (tipo1 == 1){
				p1 = searchObjId(listCir, listRet, i);
				c1 = getObjt(p1);
				id1 = getCirculoId(c1);
				printSvgCirculo(&svg, c1);
				j = length(listCir);
				if (j>0){
					p1 = getFirst(listCir);
					while(j>0){
						c2 = getObjt(p1);
						if (getCirculoId(c1) != getCirculoId(c2)){
							printSvgCirculo(&svg, c2);
							printSvgLine(&svg, getCirculoX(c2), getCirculoY(c2), getCirculoX(c1), getCirculoY(c1));
						}
						p1 = getNext(p1);
						j--;
					}
					p1 = getFirst(listRet);
					j = length(listRet);
					while(j>0){
						r2 = (Retangulo)getObjt(p1);
						printSvgRetangulo(&svg, r2);
						printSvgLine(&svg, getCirculoX(c1), getCirculoY(c1), (getRetanguloX(r2)+getRetanguloWidth(r2)/2), (getRetanguloY(r2)+getRetanguloHeight(r2)/2));
						p1 = getNext(p1);
						j--;
					}
				}
			}
			if (tipo1 != -1){
				fprintf(svg, "</svg>");
			}else
				printf("ERRO\n");
			fclose(svg);
		}else if (strcmp(word, "#") == 0){
			break;
		}else if (strcmp(word, "q?") == 0){
			sscanf(line, "%s %lf %lf %lf %lf", word, &x, &y, &width, &height);
			if (txt == NULL){
				aux = funcTxt(argc, argv);
				txt = fopen(aux, "w");
				funcFree(&aux);
			}
			r1 = creatRetangulo(0, width, height, x, y, NULL, NULL);
			consultaQ(txt, (Item)r1, listQua, quadraInternaRetangulo);
			consultaQ(txt, (Item)r1, listHid, hidranteInternoRetangulo);
			consultaQ(txt, (Item)r1, listTor, torreInternaRetangulo);
			consultaQ(txt, (Item)r1, listSem, semaforoInternoRetangulo);
			fprintf(*svgMain, "<rect x=\"%f\" y=\"%f\" width=\"%f\" height=\"%f\" fill=\"gray\" stroke=\"red\" stroke-width=\"3\" fill-opacity = \"0.0\" stroke-dasharray = \"5,5,5\"/>\n", x, y, width, height);
			svgCmpRetangulo(svgH, svgW, getRetanguloX(r1), getRetanguloY(r1), getRetanguloHeight(r1), getRetanguloWidth(r1));
			free(r1);
		} else if (strcmp(word, "Q?") == 0){
			sscanf(line, "%s %lf %lf %lf", word, &raio, &x, &y);
			if (txt == NULL){
				aux = funcTxt(argc, argv);
				txt = fopen(aux, "w");
				funcFree(&aux);
			}
			c1 = creatCirculo(0, raio, x, y, NULL, NULL);
			consultaQ(txt, (Item)c1, listQua, quadraInternaCirculo);
			consultaQ(txt, (Item)c1, listTor, torreInternaCirculo);
			consultaQ(txt, (Item)c1, listHid, hidranteInternoCirculo);
			consultaQ(txt, (Item)c1, listSem, semaforoInternoCirculo);
			fprintf(*svgMain, "<circle cx = \"%f\" cy = \"%f\" r = \"%f\" fill = \"gray\" stroke=\"red\" stroke-width=\"3\" fill-opacity = \"0.0\" stroke-dasharray = \"5,5,5\"/>\n", x, y, raio);
			svgCmpCirculo(svgH, svgW, getCirculoX(c1), getCirculoY(c1), getCirculoRaio(c1));

			free(c1);
		} else if (strcmp(word, "dq") == 0){
			sscanf(line, "%s %lf %lf %lf %lf", word, &x, &y, &width, &height);
			if (length(listQua) > 0){
				if (txt == NULL){
					aux = funcTxt(argc, argv);
					txt = fopen(aux, "w");
					funcFree(&aux);
				}
				aux = (char*)malloc(sizeof(char)*6);
				aux2 = (char*)malloc(sizeof(char)*7);
				strcpy(aux, "green");
				strcpy(aux2, "yellow");
				r1  = creatRetangulo(0, width, height, x, y, aux, aux2);
				p1 = getFirst(listQua);
				q1 = (Quadra)getObjt(p1);
				i = length(listQua);
				while(i>0){
					var = cmpQuadra(q1, x, y, width, height);
					if (var == 1){
						fprintf(txt, "%s\n", getQuadraCep(q1));
						freeQuadra(q1);
						p2 = getNext(p1);
						remover(listQua, p1);
					} else
						p2 = getNext(p1);
					p1 = p2;
					if (p1 != NULL)
						q1 = getObjt(p1);
					else
						break;
					i--;
				}
				printSvgRetangulo(svgMain, r1);
				svgCmpRetangulo(svgH, svgW, getRetanguloX(r1), getRetanguloY(r1), getRetanguloHeight(r1), getRetanguloWidth(r1));
				funcFree(&aux);
				funcFree(&aux2);
				if (r1 != NULL)
					free(r1);
			}
		} else if (strcmp(word, "dle") == 0){
			sscanf(line, "%s %s %lf %lf %lf %lf", word, tipo, &x, &y, &width, &height);
			aux = (char*)malloc(sizeof(char)*6);
			aux2 = (char*)malloc(sizeof(char)*7);
			strcpy(aux, "green");
			strcpy(aux2, "yellow");
			r1  = creatRetangulo(0, width, height, x, y, aux, aux2);
			if (txt == NULL){
				aux3 = funcTxt(argc, argv);
				txt = fopen(aux3, "w");
				funcFree(&aux3);
			}
			if (strcmp(tipo, "t") == 0){
				p1 = getFirst(listTor);
				t1 = getObjt(p1);
				i = length(listTor);
				
				while(i>0){
					var = torreInternaRetangulo(&lixo, t1, r1);
					if (var == 1){
						fprintf(txt, "%s\n", getTorreId(t1));
						freeTorre(t1);
						p2 = getNext(p1);
						remover(listTor, p1);
						p1 = p2;
					}else
						p1 = getNext(p1);
					if (p1 != NULL)
						t1 = getObjt(p1);
					i--;
				}
			} else if (strcmp(tipo, "s") == 0){
				p1 = getFirst(listSem);
				s1 = getObjt(p1);
				i = length(listSem);
				while(i>0){
					var = semaforoInternoRetangulo(&lixo, s1, r1);
					if (var == 1){
						fprintf(txt, "%s\n", getSemaforoId(s1));
						freeSemaforo(s1);
						p2 = getNext(p1);
						remover(listSem, p1);
						p1 = p2;
					}else
						p1 = getNext(p1);
					if (p1 != NULL)
						s1 = getObjt(p1);
					i--;
				}
			} else if(strcmp(word, "h") == 0){
				p1 = getFirst(listHid);
				h1 = getObjt(p1);
				i = length(listHid);
				while(i>0){
					var = hidranteInternoRetangulo(&lixo, h1, r1);
					if (var == 1){
						fprintf(txt, "%s\n", getHidranteId(h1));
						freeHidrante(h1);
						p2 = getNext(p1);
						remover(listHid, p1);
						p1 = p2;
					}else
						p1 = getNext(p1);
					if (p1 != NULL)
						h1 = getObjt(p1);
					i--;
				}
			}
			funcFree(&aux);
			funcFree(&aux2);
			if (r1 != NULL)
				free(r1);
		} else if (strcmp(word, "Dq") == 0){
			sscanf(line, "%s %lf %lf %lf", word, &raio, &x, &y);
			if (txt == NULL){
				aux = funcTxt(argc, argv);
				txt = fopen(aux, "w");
				funcFree(&aux);
			}
			aux = (char*)malloc(sizeof(char)*6);
			aux2 = (char*)malloc(sizeof(char)*7);
			strcpy(aux, "green");
			strcpy(aux2, "yellow");
			c1  = creatCirculo(0, raio, x, y, aux, aux2);
			p1 = getFirst(listQua);
			q1 = (Quadra)getObjt(p1);
			i = length(listQua);
			while(i>0){
				var = quadraInternaCirculo(&lixo, q1, c1);
				if (var == 1){
					fprintf(txt, "%s\n", getQuadraCep(q1));
					freeQuadra(q1);
					p2 = getNext(p1);
					remover(listQua, p1);
				} else
					p2 = getNext(p1);
				p1 = p2;
				if (p1 != NULL)
					q1 = getObjt(p1);
				else
					break;
				i--;
			}
			printSvgCirculo(svgMain, c1);
			svgCmpCirculo(svgH, svgW, getCirculoX(c1), getCirculoY(c1), getCirculoRaio(c1));
			freeCirculo(c1);
			if (c1 != NULL)
				free(c1);
		} else if (strcmp(word, "Dle") == 0){
			sscanf(line, "%s %s %lf %lf %lf", word, tipo, &x, &y, &raio);
			if (txt == NULL){
				aux = funcTxt(argc, argv);
				txt = fopen(aux, "w");
				funcFree(&aux);
			}
			c1  = creatCirculo(0, raio, x, y, NULL, NULL);
			if (strcmp(tipo, "t") == 0){
				p1 = getFirst(listTor);
				t1 = getObjt(p1);
				i = length(listTor);
				while(i>0){
					var = torreInternaCirculo(&lixo, t1, c1);
					if (var == 1){
						fprintf(txt, "%s\n", getTorreId(t1));
						freeTorre(t1);
						p2 = getNext(p1);
						remover(listTor, p1);
						p1 = p2;
					}else
						p1 = getNext(p1);
					if (p1 != NULL)
						t1 = getObjt(p1);
					i--;
				}
			} else if (strcmp(tipo, "s") == 0){
				p1 = getFirst(listSem);
				s1 = getObjt(p1);
				i = length(listSem);
				while(i>0){
					var = semaforoInternoCirculo(&lixo, s1, c1);
					if (var == 1){
						fprintf(txt, "%s\n", getSemaforoId(s1));
						freeSemaforo(s1);
						p2 = getNext(p1);
						remover(listSem, p1);
						p1 = p2;
					}else
						p1 = getNext(p1);
					if (p1 != NULL)
						s1 = getObjt(p1);
					i--;
				}
			} else if(strcmp(word, "h") == 0){
				p1 = getFirst(listHid);
				h1 = getObjt(p1);
				i = length(listHid);
				while(i>0){
					var = hidranteInternoCirculo(&lixo, h1, c1);
					if (var == 1){
						fprintf(txt, "%s\n", getHidranteId(h1));
						freeHidrante(h1);
						p2 = getNext(p1);
						remover(listHid, p1);
						p1 = p2;
					}else
						p1 = getNext(p1);
					if (p1 != NULL)
						h1 = getObjt(p1);
					i--;
				}
			}
			if (c1 != NULL)
				free(c1);
		} else if (strcmp(word, "cc") == 0){
			sscanf(line, "%s %s %s %s", word, cep, cor1, cor2);
			aux = (char*)malloc(sizeof(char)*(strlen(cor1) + 1));
			aux2 = (char*)malloc(sizeof(char)*(strlen(cor2) + 1));
			strcpy(aux, cor1);
			strcpy(aux2, cor2);
			p1 = searchObjCep(listQua, cep, getQuadraCep);
			if (p1 == NULL){
				p1 = searchObjCep(listTor, cep, getTorreId);
				if (p1 == NULL){
					p1 = searchObjCep(listHid, cep, getHidranteId);
					if (p1 == NULL){
						p1 = searchObjCep(listSem, cep, getSemaforoId);
						if (p1 != NULL){
							s1 = (Semaforo)getObjt(p1);
							setSemaforoCorContorno(s1, aux);
							setSemaforoCorPreenchimento(s1, aux2);
						}
					}else{
						h1 = (Hidrante)getObjt(p1);
						setHidranteCorContorno(h1, aux);
						setHidranteCorPreenchimento(h1, aux2);
					}
				} else{
					t1 = (Torre)getObjt(p1);
					setTorreCorPreenchimento(t1, aux2);
					setTorreCorContorno(t1, aux);
				}
			} else{
				q1 = (Quadra)getObjt(p1);
				setQuadraCorContorno(q1, aux);
				setQuadraCorPreenchimento(q1, aux2);
			}
		}else if (strcmp(word, "crd?") == 0){
			sscanf(line, "%s %s", word, cep);
			if (txt == NULL){
				aux = funcTxt(argc, argv);
				txt = fopen(aux, "w");
				funcFree(&aux);
			}
			p1 = searchObjCep(listQua, cep, getQuadraCep);
			if (p1 == NULL){
				p1 = searchObjCep(listTor, cep, getTorreId);
				if (p1 == NULL){
					p1 = searchObjCep(listHid, cep, getHidranteId);
					if (p1 == NULL){
						p1 = searchObjCep(listSem, cep, getSemaforoId);
						if (p1 != NULL){
							s1 = (Semaforo)getObjt(p1);
							fprintf(txt, "Semaforo %lf %lf\n", getSemaforoX(s1), getSemaforoY(s1));
						}
					}else{
						h1 = (Hidrante)getObjt(p1);
						fprintf(txt, "Hidrante %lf %lf\n", getHidranteX(h1), getHidranteY(h1));
					}
				} else{
					t1 = (Torre)getObjt(p1);
					fprintf(txt, "Torre %lf %lf\n", getTorreX(t1), getTorreY(t1));
				}
			} else{
				q1 = (Quadra)getObjt(p1);
				fprintf(txt, "Quadra %lf %lf\n", getQuadraX(q1), getQuadraY(q1));
			}
		}else if (strcmp(word, "crb?") == 0){
			Vector vetor;
			Elemento e1 = NULL, e2 = NULL;
			aux = NULL;
			Posic p;
			Elemento e;
			vetor = ltov(listTor, getTorreX, getTorreY, getTorreId);
			heapSort(vetor, cmp, 'x');
			value = lessDistance(vetor, 1, getSizeVector(vetor), &e1, &e2);
			fprintf(*svgMain, "<circle cx = \"%f\" cy = \"%f\" r = \"120\" fill = \"gray\" stroke=\"red\" stroke-width=\"15\" fill-opacity = \"0.0\" />\n", getElementoX(e1), getElementoY(e1));
			fprintf(*svgMain, "<circle cx = \"%f\" cy = \"%f\" r = \"120\" fill = \"gray\" stroke=\"red\" stroke-width=\"15\" fill-opacity = \"0.0\" />\n", getElementoX(e2), getElementoY(e2));
			freeVector(vetor, freeElemento);
		}
		else if(strcmp(word, "m?") == 0){
			int v = 0;
			sscanf(line, "%s %s", word, cep);
			if (txt == NULL){
				aux = funcTxt(argc, argv);
				txt = fopen(aux, "w");
				funcFree(&aux);
			}
			fprintf(txt, "#####################################\n");
			fprintf(txt, "Consulta moradores da quadra %s:\n", cep);
			
			for(p1 = getFirst(listQua); p1 != NULL; p1 = getNext(p1)){
				q1 = (Quadra)getObjt(p1);
				if(strcmp(getQuadraCep(q1), cep) == 0){
					v = 1; //quadra existe
				}
			}
			if(v == 1){
				for(p1 = getFirst(listPessoa); p1 != NULL; p1 = getNext(p1)){
					pessoa1 = (Pessoa)getObjt(p1); //retorna struct pessoa atual
					end1 = (Endereco)getPessoaEndereco(pessoa1); //retorna struct endereco dessa pessoa
					if(end1 != NULL){
						if(strcmp(getEnderecoCep(end1), cep) == 0){
							v = 2;
							fprintf(txt, "	nome morador: %s\n", getPessoaNome(pessoa1));
							fprintf(txt, "	sobrenome morador: %s\n", getPessoaSobreNome(pessoa1));
							fprintf(txt, "	cep da rua: %s", cep);
							fprintf(txt, "	numero da rua: %d\n", getEnderecoNum(end1));
							fprintf(txt, "	complemento: %s\n\n", getEnderecoComplm(end1));
						}
					}
				}
			}
			else if (v == 0){
				fprintf(txt, "	Quadra nao existe.\n");
			}
			if (v == 1)	fprintf(txt, "	nao existem moradores nesta quadra.\n");
		}
		else if(strcmp(word, "mr?") == 0){
			sscanf(line, "%s %lf %lf %lf %lf", word, &x, &y, &width, &height);
			if (txt == NULL){
				aux = funcTxt(argc, argv);
				txt = fopen(aux, "w");
				funcFree(&aux);
			}
			fprintf(txt, "#####################################\n");
			fprintf(txt, "Consulta moradores da regiao do retangulo com dimensoes x: %f, y: %f, largura: %f e altura : %f:\n", x, y, width, height);
			for(p1 = getFirst(listQua); p1 != NULL; p1 = getNext(p1)){
				q1 = getObjt(p1); //retorna struct quadra atual
				if(verificaQuadraInternaRegiaoRet(q1, x, y, width, height) == 1){
					strcpy(cep, getQuadraCep(q1));
					for(p2 = getFirst(listPessoa); p2 != NULL; p2 = getNext(p2)){
						pessoa1 = getObjt(p2); //retorna struct pessoa atual
						end1 = getPessoaEndereco(pessoa1); //retorna endereco da pessoa atual
						if(end1 != NULL){ 
							if(strcmp(getEnderecoCep(end1), cep) == 0){ //é morador da quadra
								fprintf(txt, "	nome morador: %s\n", getPessoaNome(pessoa1));
								fprintf(txt, "	sobrenome morador: %s\n", getPessoaSobreNome(pessoa1));
								fprintf(txt, "	cep da rua: %s", cep);
								fprintf(txt, "	numero da rua: %d\n", getEnderecoNum(end1));
								fprintf(txt, "	complemento: %s\n\n", getEnderecoComplm(end1));
							}
						}
					}
				}				
			}
		}
		else if(strcmp(word, "dm?") == 0){
			sscanf(line, "%s %s", word, cpf);
			if (txt == NULL){
				aux = funcTxt(argc, argv);
				txt = fopen(aux, "w");
				funcFree(&aux);
			}
			fprintf(txt, "#####################################\n");
			fprintf(txt, "Consulta dados do morador com cpf %s:\n", cpf);
				
				elementCpf_DadosPessoa = searchHash(hashCpf_DadosPessoa, cpf, getHashElementId); //retorna struct {(String)cpf x (Pessoa)DadosPessoa} referente ao cpf dado no parametro
				if(elementCpf_DadosPessoa){
					pessoa1 = getHashElementKey(elementCpf_DadosPessoa); //extrai apenas o elemento (Pessoa)DadosPessoa dessa struct
				
					fprintf(txt, "	nome morador: %s\n", getPessoaNome(pessoa1));
					fprintf(txt, "	sobrenome morador: %s\n", getPessoaSobreNome(pessoa1));
					fprintf(txt, "	sexo morador: %s\n", getPessoaSexo(pessoa1));
					fprintf(txt, "	data de Nascimento morador: %s\n", getPessoaNasc(pessoa1));
					end1 = getPessoaEndereco(pessoa1);
					fprintf(txt, "	dados de endereco:\n");
					if(end1 != NULL){
						fprintf(txt, "	cep: %s\n", getEnderecoCep(end1));
						fprintf(txt, "	face: %s\n", getEnderecoFace(end1));
						fprintf(txt, "	numero: %d\n", getEnderecoNum(end1));
						fprintf(txt, "	complemento: %s\n", getEnderecoComplm(end1));
					}
					else
						fprintf(txt, "	morador nao possui endereco.\n");
					elementCpf_Quadra = searchHash(hashCpf_Quadra, cpf, getHashElementId); // retorna struct {cpf x Quadra} referente ao cpf dado no parametro
					q1 = getHashElementKey(elementCpf_Quadra); //retorna quadra dessa struct
					/*if(c1 != NULL)	
						free(c1);*/
					aux = calloc(4, sizeof(char));
					aux2 = calloc(4, sizeof(char));
					strcpy(aux, "red");
					strcpy(aux2, "red");
					c1 = creatCirculo(0, 10.0, getEnderecoPosicX(end1, q1), getEnderecoPosicY(end1, q1), aux, aux2);
					insert(listCir, (Item)c1);
				}
				else{
					fprintf(txt, "	Morador nao existe.\n");
				}
		}
		else if(strcmp(word, "de?") == 0){
			int v = 0;
			sscanf(line, "%s %s", word, cnpj);
			if (txt == NULL){
				aux = funcTxt(argc, argv);
				txt = fopen(aux, "w");
				funcFree(&aux);
			}
			fprintf(txt, "#####################################\n");
			fprintf(txt, "Consulda dados do estabelecimento com cnpj %s:\n", cnpj);
			for(p1 = getFirst(listQua); p1 != NULL; p1 = getNext(p1)){
				q1 = getObjt(p1);
				for(p2 = getFirst(getQuadraListEstab(q1)); p2 != NULL; p2 = getNext(p2)){
					estab1 = getObjt(p2);
					if(strcmp(getEstabCNPJ(estab1), cnpj) == 0){
						fprintf(txt, "	nome estabelecimento: %s\n", getEstabNome(estab1));
						fprintf(txt, "	Tipo: %s\n", getEstabTipo(estab1));
						fprintf(txt, "	CEP: %s\n", getEstabCep(estab1));
						fprintf(txt, "	Face: %s\n", getEstabFace(estab1));
						fprintf(txt, "	Numero: %d\n", getEstabNum(estab1));
						v = 1;
						aux = calloc(4, sizeof(char));
						aux2 = calloc(4, sizeof(char));
						strcpy(aux, "red");
						strcpy(aux2, "red");
						c1 = creatCirculo(0, 10.0, getEstabPosicX(estab1, q1), getEstabPosicY(estab1, q1), aux, aux2);
						insert(listCir, (Item)c1);
						break;
					}
				}
				if(v == 1) break;
			}
		}
		else if(strcmp(word, "rip") == 0){
			sscanf(line, "%s %s", word, cpf);
			if (txt == NULL){
				aux = funcTxt(argc, argv);
				txt = fopen(aux, "w");
				funcFree(&aux);
			}
			elementCpf_DadosPessoa = searchHash(hashCpf_DadosPessoa, cpf, getHashElementId); 
			if(elementCpf_DadosPessoa){
				pessoa1 = getHashElementKey(elementCpf_DadosPessoa); //retorna struct pessoa;
				end1 = getPessoaEndereco(pessoa1);
				fprintf(txt, "#####################################\n");
				fprintf(txt, "É com pesar que informamos a morte ");
				if(strcmp(getPessoaSexo(pessoa1), "F") == 0)
				{
					fprintf(txt, "da Sra. %s %s,\n", getPessoaNome(pessoa1), getPessoaSobreNome(pessoa1));
					fprintf(txt, "nascida em %s,\n", getPessoaNasc(pessoa1));
				}
				else
				{
					fprintf(txt, "do Sr. %s %s,\n", getPessoaNome(pessoa1), getPessoaSobreNome(pessoa1));
					fprintf(txt, "nascido em %s,\n", getPessoaNasc(pessoa1));
				}
				if(end1 == NULL)
					fprintf(txt, "e que era um sem-teto.\n");
				else
					fprintf(txt, "e que residia no endereco %s, \ncom numero %d e face %s.\n", getEnderecoCep(end1), getEnderecoNum(end1), getEnderecoFace(end1));
				deleteHashElement(hashCpf_DadosPessoa, cpf, getHashElementId); //remove vestigios da pessoa nas hashes, se houver
				deleteHashElement(hashCpf_Cep, cpf, getHashElementId); 
				deleteHashElement(hashCpf_Quadra, cpf, getHashElementId);
				for(p1 = getFirst(listPessoa); p1 != NULL; p1 = getNext(p1)){
					if(getObjt(p1) == pessoa1){
						remover(listPessoa, p1); //remove pessoa da lista de Pessoas
					}
				}
			}
			else {
				fprintf(txt, "Pessoa nao existe.\n");
			}
		}
		else if(strcmp(word, "ecq?") == 0){
			sscanf(line, "%s %s", word, cep);
			if (txt == NULL){
				aux = funcTxt(argc, argv);
				txt = fopen(aux, "w");
				funcFree(&aux);
			}
			fprintf(txt, "#####################################\n");
			fprintf(txt, "Consulta dados dos estabelecimentos na quadra com cep %s:\n", cep);
			i = 1;
			q1 = searchHash(hashCep_Quadra, cep, getQuadraCep); //extrai apenas a quadra 
			if(q1){
				for(p1 = getFirst(getQuadraListEstab(q1)); p1 != NULL; p1 = getNext(p1)){ //percorre lista de Comercios da quadra
					estab1 = getObjt(p1);
					fprintf(txt, "Estabelecimento Comercial %d:\n", i);
					fprintf(txt, "	Nome estabelecimento: %s\n", getEstabNome(estab1));
					fprintf(txt, "	Tipo: %s\n", getEstabTipo(estab1));
					fprintf(txt, "	Face: %s\n", getEstabFace(estab1));
					fprintf(txt, "	Numero: %d\n", getEstabNum(estab1));
					fprintf(txt, "	CNPJ: %s\n", getEstabCNPJ(estab1));
					i++;
				}
			}
		}
		else if(strcmp(word, "ecr?") == 0){
			sscanf(line, "%s %s %lf %lf %lf %lf", word, codt, &x, &y, &width, &height);
			if (txt == NULL){
				aux = funcTxt(argc, argv);
				txt = fopen(aux, "w");
				funcFree(&aux);
			}
			fprintf(txt, "#####################################\n");
			fprintf(txt, "Consulta dados dos estabelecimentos na regiao do retangulo com dimensoes x: %f, y: %f, largura: %f e altura : %f:\n", x, y, width, height);
			elementCodt_Desc = searchHash(hashCodt_Desc, codt, getHashElementId); //retorna struct {(Strng)codt x (String)Desc}
			tipo = malloc(sizeof(getHashElementKey(elementCodt_Desc) + 1));
			strcpy(tipo, getHashElementKey(elementCodt_Desc)); //extrai Desc dessa struct
			i = 1;
			
			for(p1 = getFirst(listQua); p1 != NULL; p1 = getNext(p1)){
				q1 = getObjt(p1); //retorna struct Quadra
				if(verificaQuadraInternaRegiaoRet(q1, x, y, width, height) == 1){
					for(p2 = getFirst(getQuadraListEstab(q1)); p2 != NULL; p2 = getNext(p2)){ //percorre lista de estabelecimentos pertencentes a quadra
						estab1 = getObjt(p2);
						fprintf(txt, "Estabelecimento Comercial %d:\n", i);
						fprintf(txt, "	Nome estabelecimento: %s\n", getEstabNome(estab1));
						fprintf(txt, "	Tipo: %s\n", getEstabTipo(estab1));
						fprintf(txt, "	Cep: %s\n", getEstabCep(estab1));
						fprintf(txt, "	Face: %s\n", getEstabFace(estab1));
						fprintf(txt, "	Numero: %d\n", getEstabNum(estab1));
						fprintf(txt, "	CNPJ: %s\n", getEstabCNPJ(estab1));
						i++;
					}
				}
			}
			if(i == 1){
				fprintf(txt, "Nao existem Estabelecimentos Comerciais na regiao estabelecida.\n");
			}
		}
		else if(strcmp(word, "tecq?") == 0){
			sscanf(line, "%s %s", word, cep);
			if (txt == NULL){
				aux = funcTxt(argc, argv);
				txt = fopen(aux, "w");
				funcFree(&aux);
			}
			fprintf(txt, "#####################################\n");
			fprintf(txt, "Consulta tipo e nome dos estabelecimentos na Quadra com cep %s:\n", cep);
			q1 = searchHash(hashCep_Quadra, cep, getQuadraCep); //extrai apenas a quadra 
			if(q1){
				i = 1;
				for(p1 = getFirst(getQuadraListEstab(q1)); p1 != NULL; p1 = getNext(p1)){
					estab1 = getObjt(p1);
					fprintf(txt, "Estabelecimento Comercial %d:\n", i);
					fprintf(txt, "	tipo: %s\n", getEstabTipo(estab1));
					fprintf(txt, "	Nome: %s\n\n", getEstabNome(estab1));
				}
			}
		}
		else if(strcmp(word, "tecr?") == 0){
			i = 1;
			sscanf(line, "%s %lf %lf %lf %lf", word, &x, &y, &width, &height);
			if (txt == NULL){
				aux = funcTxt(argc, argv);
				txt = fopen(aux, "w");
				funcFree(&aux);
			}
			fprintf(txt, "#####################################\n");
			fprintf(txt, "Consulta tipo e nome dos estabelecimentos na regiao do retangulo de dimensoes x: %f, y: %f, largura: %f e altura : %f:\n", x, y, width, height);
			for(p1 = getFirst(listQua); p1 != NULL; p1 = getNext(p1)){
				q1 = getObjt(p1);
				if(verificaQuadraInternaRegiaoRet(q1, x, y, width, height) == 1){
					for(p2 = getFirst(getQuadraListEstab(q1)); p2 != NULL; p2 = getNext(p2)){
						estab1 = getObjt(p2);
						fprintf(txt, "Estabelecimento Comercial %d:\n", i);
						fprintf(txt, "	tipo: %s\n", getEstabTipo(estab1));
						fprintf(txt, "	Nome: %s\n\n", getEstabNome(estab1));
						i++;
					}
				}
			}
		}
		else if(strcmp(word, "fec") == 0){
			int v;
			if (txt == NULL){
				aux = funcTxt(argc, argv);
				txt = fopen(aux, "a");
				funcFree(&aux);
			}
			fprintf(txt, "#####################################\n");
			fprintf(txt, "Infelizmente, um estabelecimento comercial foi fechado. Dados do (antigo)estabelecimento:\n");
			sscanf(line, "%s %s", word, cnpj);
			for(p1 = getFirst(listQua); p1 != NULL; p1 = getNext(p1)){
				q1 = getObjt(p1);
				for(p2 = getFirst(getQuadraListEstab(q1)); p2 != NULL; p2 = getNext(p2)){
					estab1 = getObjt(p2);
					if(strcmp(getEstabCNPJ(estab1), cnpj) == 0){
						fprintf(txt, "	Nome: %s\n", getEstabNome(estab1));
						fprintf(txt, "	Tipo: %s\n", getEstabTipo(estab1));
						fprintf(txt, "	Cep: %s\n", getEstabCep(estab1));
						fprintf(txt, "	Face: %s\n", getEstabFace(estab1));
						fprintf(txt, "	Numero: %d\n", getEstabNum(estab1));
						fprintf(txt, "	CNPJ: %s\n", getEstabCNPJ(estab1));
						deleteQuadraEstab(q1, p2); //deleta elemento da lista de quadras
						v = 1;
						break;
					}
				}
				if(v == 1)	break;
			}
		}
		else if(strcmp(word, "mud") == 0){
			if (txt == NULL){
				aux = funcTxt(argc, argv);
				txt = fopen(aux, "a");
				funcFree(&aux);
			}
			fprintf(txt, "#####################################\n");
			sscanf(line, "%s %s %s %s %d %s", word, cpf, cep, face, &num, complm);
			elementCpf_DadosPessoa = searchHash(hashCpf_DadosPessoa, cpf, getHashElementId); //retorna struct {(string)cpf x (Pessoa)pessoa}
			if(elementCpf_DadosPessoa){
				pessoa1 = getHashElementKey(elementCpf_DadosPessoa); // extrai (Pessoa)pessoa da struct
				if(getPessoaSexo(pessoa1) == "F")
					fprintf(txt, "Informamos que a Sra. %s %s mudou de endereço.\n", getPessoaNome(pessoa1), getPessoaSobreNome(pessoa1));
				else
					fprintf(txt, "Informamos que o Sr. %s %s mudou de endereço.\n", getPessoaNome(pessoa1), getPessoaSobreNome(pessoa1));
				fprintf(txt, "Endereço antigo:\n");
				end1 = getPessoaEndereco(pessoa1);
				if(end1){
					fprintf(txt, "Cep: %s\n", getEnderecoCep(end1));
					fprintf(txt, "Face: %s\n", getEnderecoFace(end1));
					fprintf(txt, "Numero: %d\n", getEnderecoNum(end1));
					fprintf(txt, "complemento: %s\n", getEnderecoComplm(end1));
					freePessoaEndereco(pessoa1);
				}
				else{
					fprintf(txt, "nao havia.\n");
				}
				end1 = createEndereco(cep, face, num, complm);
				setPessoaEndereco(pessoa1, end1); 
				fprintf(txt, "\nEndereço novo:\n");
				fprintf(txt, "Cep: %s\n", getEnderecoCep(end1));
				fprintf(txt, "Face: %s\n", getEnderecoFace(end1));
				fprintf(txt, "Numero: %d\n", getEnderecoNum(end1));
				fprintf(txt, "complemento: %s\n", getEnderecoComplm(end1));
			}
		}
		else if(strcmp(word, "hmpe?") == 0){
			sscanf(line, "%s %s %s %d", word, cep, face, &num);
			double menor, dist;
			q1 = buscarItemKdTree(kd_quadra, cep, comparaQuadra);
			Hidrante h2, certo;
			h1 = cmdHmpe(q1, face, num);
			Lista l1;
			l1 = kdTreeParaLista(kd_hid);
			Posic p = getFirst(l1);
			h2 = getObjt(p);
			menor = distanciaEntrePontos(getHidranteX(h1), getHidranteY(h1), getHidranteX(h2), getHidranteY(h2));
			for(int i = 1; i<length(l1); i++){
				p = getNext(p);
				if (p == NULL)
					break;
				h2 = getObjt(p);
				dist = distanciaEntrePontos(getHidranteX(h1), getHidranteY(h1), getHidranteX(h2), getHidranteY(h2));
				if (dist < menor){
					menor = dist;
					certo = h2;
				}
			}
			/*vet = ltov(l1, getHidranteX, getHidranteY, getHidranteId);
			heapSort(vet, cmp, 'x');
			/*for(i = 1; i<=getSizeVector(vet); i++){
				e1 = getObjVector(vet, i);
				printf("x: %f y: %f\n", getElementoX(e1), getElementoY(e1));
			}
			x = elementCloser(getHidranteX(h1), getHidranteY(h1), vet, &e1, 'x');
			heapSort(vet, cmp, 'y');
			y = elementCloser(getHidranteX(h1), getHidranteY(h1), vet, &e2, 'y');*/
			fprintf(*svgMain, "<text x  = \"%f\" y = \"%f\" font-family=\"Arial\" font-size = \"20\">X</text>", getHidranteX(h1), getHidranteY(h1));
			if (txt == NULL){
				aux = funcTxt(argc, argv);
				txt = fopen(aux, "a");
				funcFree(&aux);
			}
			fprintf(txt, "Hidrante %s, coodn(%f, %f) à distância de %f do endereço", getHidranteId(certo), getHidranteX(certo), getHidranteY(certo), menor);
			fprintf(*svgMain, "<line x1=\"%f\" y1=\"%f\" x2=\"%f\" y2=\"%f\" stroke=\"purple\" stroke-width=\"2\"  stroke-dasharray = \"2,2,2\"/>\n",getHidranteX(certo), getHidranteY(certo), getHidranteX(h1), getHidranteY(h1));
			/*if (x < y){
				printf("%s\n", getElementoId(e1));
				getchar();
				fprintf(txt, "Hidrante %s, coodn(%f, %f) à distância de %f do endereço", getHidranteId(certo), getHidranteX(certo), getHidranteY(certo), x);
				fprintf(*svgMain, "<line x1=\"%f\" y1=\"%f\" x2=\"%f\" y2=\"%f\" stroke=\"purple\" stroke-width=\"4\"  stroke-dasharray = \"5,10,2\"/>\n",getHidranteX(certo), getHidranteY(certo), getHidranteX(h1), getHidranteY(h1));
			} else{
				fprintf(txt, "Hidrante %s, coodn(%f, %f) à distância de %f do endereço", getElementoId(e2), getElementoX(e2), getElementoY(e2), y);
				fprintf(*svgMain, "<line x1=\"%f\" y1=\"%f\" x2=\"%f\" y2=\"%f\" stroke=\"purple\" stroke-width=\"4\"  stroke-dasharray = \"5,10,2\"/>\n",getElementoX(e2), getElementoY(e2), getHidranteX(h1), getHidranteY(h1));
			}*/
			freeHidrante(h1);
			deleteListComplete(l1, NULL);
		}else if (strcmp(word, "hmp?")==0){
			sscanf(line, "%s %s", word, cep);
			t1 = buscarItemKdTree(kd_torre, cep, cmpTorre);
			double dist, menor;
			Hidrante h2;
			Lista list;
			list = kdTreeParaLista(kd_hid);
			Posic p;
			p = getFirst(list);
			h1 = getObjt(p);
			menor = distanciaEntrePontos(getHidranteX(h1), getHidranteY(h1), getTorreX(t1), getTorreY(t1));
			for (i = 0; i < length(list); i++){
				p = getNext(p);
				if (p == NULL)
					break;
				h2 = getObjt(p);
				dist = distanciaEntrePontos(getHidranteX(h2), getHidranteY(h2), getTorreX(t1), getTorreY(t1));
				if (dist < menor){
					menor = dist;
					h1 = h2;
				}
			}
			fprintf(*svgMain, "<text x  = \"%f\" y = \"%f\" font-family=\"Arial\" font-size = \"20\">X</text>", getHidranteX(h1), getHidranteY(h1));
			if (txt == NULL){
				aux = funcTxt(argc, argv);
				txt = fopen(aux, "a");
				funcFree(&aux);
			}
			fprintf(txt, "Hidrante %s, coodn(%f, %f) à distância de %f do endereço", getHidranteId(h1), getHidranteX(h1), getHidranteY(h1), menor);
			fprintf(*svgMain, "<line x1=\"%f\" y1=\"%f\" x2=\"%f\" y2=\"%f\" stroke=\"purple\" stroke-width=\"2\"  stroke-dasharray = \"2,2,2\"/>\n",getHidranteX(h1), getHidranteY(h1), getTorreX(t1), getTorreY(t1));
			deleteListComplete(list, NULL);
		} else if(strcmp(word, "mudec")==0){
			int v = 0;
			sscanf(line, "%s %s %s %s %d", word, cnpj, cep, face, &num);
			if (txt == NULL){
				aux = funcTxt(argc, argv);
				txt = fopen(aux, "w");
				funcFree(&aux);
			}
			fprintf(txt, "#####################################\n");
			fprintf(txt, "Informamos que o estabelecimento com cnpj %s se mudou.\n", cnpj);
			for(p1 = getFirst(listQua); p1 != NULL; p1 = getNext(p1)){
				q1 = getObjt(p1);
				for(p2 = getFirst(getQuadraListEstab(q1)); p2 != NULL; p2 = getNext(p2)){
					estab1 = getObjt(p2);
					if(strcmp(getEstabCNPJ(estab1), cnpj) == 0){
						fprintf(txt, "	nome estabelecimento: %s\n", getEstabNome(estab1));
						fprintf(txt, "	Tipo: %s\n", getEstabTipo(estab1));
						fprintf(txt, "	CEP antigo: %s\n", getEstabCep(estab1));
						fprintf(txt, "	Face antigo: %s\n", getEstabFace(estab1));
						fprintf(txt, "	Numero antigo: %d\n", getEstabNum(estab1));
						fprintf(txt, "	CEP novo: %s\n", cep);
						fprintf(txt, "	Face novo: %s\n", face);
						fprintf(txt, "	Numero novo: %d\n", num);
						
						setEstabCep(estab1, cep);
						setEstabFace(estab1, face);
						setEstabNum(estab1, num);
						v = 1;
						
						q1 = searchHash(hashCep_Quadra, getEstabCep(estab1), getQuadraCep);
						q2 = searchHash(hashCep_Quadra, cep, getQuadraCep);
						fprintf(*svgMain, "<line x1=\"%lf\" y1=\"%lf\" x2=\"%lf\" y2=\"%lf\" style=\"stroke:rgb(0,255,0);stroke-width:2\" />", getQuadraX(q1), getQuadraY(q1), getQuadraX(q2), getQuadraY(q2));

						break;
					}
				}
				if(v == 1) break;
			}
		}else if(strcmp(word, "dpr")==0){
			sscanf(line, "%s %lf %lf %lf %lf", word, &x, &y, &width, &height);
			if (txt == NULL){
				aux = funcTxt(argc, argv);
				txt = fopen(aux, "a");
				funcFree(&aux);
			}
			r1 = creatRetangulo(0, width, height, x, y, NULL, NULL);
			removerInternoRet(txt, listQua, r1, quadraInternaRetangulo);
			removerInternoRet(txt, listHid, r1, hidranteInternoRetangulo);
			removerInternoRet(txt, listTor, r1, torreInternaRetangulo);
			removerInternoRet(txt, listSem, r1, semaforoInternoRetangulo);
		}
		else if(strcmp(word, "@m?") == 0){
			char *idRegistro = calloc(50, sizeof(char));
			sscanf(line, "%s %s %s", word, idRegistro, cpf);

			long indexRegistro = extrai_Index(idRegistro);

			elementCpf_DadosPessoa = searchHash(hashCpf_DadosPessoa, cpf, getHashElementId); //retorna struct {(string)cpf x (Pessoa)pessoa}
			if(elementCpf_DadosPessoa){
				pessoa1 = getHashElementKey(elementCpf_DadosPessoa); // extrai (Pessoa)pessoa da struct
				end1 = getPessoaEndereco(pessoa1);
				q1 = searchHash(hashCep_Quadra, getEnderecoCep(end1), getQuadraCep); //retorna quadra referente ao endereco
				
				x = getEnderecoPosicX(end1, q1);
				y = getEnderecoPosicY(end1, q1);

				regis[indexRegistro].x = x; //armazena infos no registro
				regis[indexRegistro].y = y; 
			}	
		}
		else if(strcmp(word, "@e?") == 0){
			char *idRegistro = calloc(50, sizeof(char));
			sscanf(line, "%s %s %s %s %d", word, idRegistro, cep, face, &num);

			long indexRegistro = extrai_Index(idRegistro);

			q1 = searchHash(hashCep_Quadra, cep, getQuadraCep); //retorna quadra referente ao endereco

			if(q1){
				x = getQuadraX(q1);
				y = getQuadraY(q1);

				regis[indexRegistro].x = x; //armazena infos no registro
				regis[indexRegistro].y = y; 	
			}
		}
		else if(strcmp(word, "@g") == 0){// Joao Vitor - montar este comando
			char *idRegistro = calloc(50, sizeof(char));
			sscanf(line, "%s %s %s", word, idRegistro, cep);
			long ind = extrai_Index(idRegistro);
			Posic p;
			if (txt == NULL){
				aux = funcTxt(argc, argv);
				txt = fopen(aux, "a");
				funcFree(&aux);
			}
			p = searchObjCep(listSem, cep, getSemaforoId);
			if (p == NULL){
				p = searchObjCep(listHid, cep, getHidranteId);
				if (p == NULL){
					p = searchObjCep(listTor, cep, getTorreId);
					if (p == NULL)
						fprintf(txt, "Equipamento não Encontrado\n");
					else{
						t1 = getObjt(p);
						regis[ind].x = getTorreX(t1);
						regis[ind].y = getTorreY(t1);
					}
					
				} else {
					h1 = getObjt(p);
					regis[ind].x = getHidranteX(h1);
					regis[ind].y = getHidranteY(h1);

				}
			} else{
				s1 = getObjt(p);
				regis[ind].x = getSemaforoX(s1);
				regis[ind].y = getSemaforoY(s1);
			}
		}
		else if(strcmp(word, "@xy") == 0){
			char *idRegistro = calloc(50, sizeof(char));
			sscanf(line, "%s %s %lf %lf", word, idRegistro, &x, &y);

			long indexRegistro = extrai_Index(idRegistro);

			regis[indexRegistro].x = x; //armazena infos no registro
			regis[indexRegistro].y = y; 
		}
		else if(strcmp(word, "@tp?") == 0){
			char *idRegistro = calloc(50, sizeof(char));
			char *idRegistro2 = calloc(50, sizeof(char));

			sscanf(line, "%s %s %s %s", word, idRegistro, codt, idRegistro2);

			long indexRegistro = extrai_Index(idRegistro);
			long indexRegistro2 = extrai_Index(idRegistro2);
			Lista lEstab;
			double dist = LONG_MAX;
			double distTest;
			Posic p, p2;

			elementCodt_Desc = searchHash(hashCodt_Desc, codt, getHashElementId); //retorna struct {Codt x Tipo} referente ao parametro "codt" dado
			tipo = getHashElementKey(elementCodt_Desc); //extrai "Tipo" dessa struct 
			
			for(p=getFirst(listQua); p!= NULL; p=getNext(p)){
				q1 = getObjt(p);
				lEstab = getQuadraListEstab(q1);
				for(p2 = getFirst(lEstab); p2 != NULL; p2=getNext(p2)){
					estab1 = getObjt(p2);
					if(strcmp(getEstabTipo(estab1), tipo) == 0){
						distTest = calculaDistancia(getQuadraX(q1), getQuadraY(q1), regis[indexRegistro2].x, regis[indexRegistro2].y);
						if(distTest < dist){
							x = getEstabPosicX(estab1, q1);
							y = getEstabPosicY(estab1, q1);
						}
					}
				}
			}
		
			regis[indexRegistro].x = x;
			regis[indexRegistro].y = y;
			
			free(idRegistro);
			free(idRegistro2);
		}
		else if(strcmp(word, "p?") == 0){
			char *idRegistro = calloc(50, sizeof(char));
			char *idRegistro2 = calloc(50, sizeof(char));
			char *cor = calloc(50, sizeof(char));
			char *textualOuPictorica = calloc(50, sizeof(char));
			char *sufixo = calloc(50, sizeof(char));
			char *distOuTempo = calloc(50, sizeof(char));
			char *cor2 = calloc(50,sizeof(char));

			sscanf(line, "%s %s %s %s %s %s %s", word, textualOuPictorica, sufixo, distOuTempo, idRegistro, idRegistro2, cor);
		
			char *p;
		    p = strtok( line, " " );
		    while( p != NULL ) {
		      p = strtok( NULL, " " );
		    }
 
			resetGrafoInfo(grafoDir);

			long indexRegistro = extrai_Index(idRegistro);
			long indexRegistro2 = extrai_Index(idRegistro2);

			Vertice v0; //vertice inicial
			v0 = encontraVerticeMaisProxDoPonto(grafoDir, regis[indexRegistro].x, regis[indexRegistro].y);

			Vertice vEnd; //vertice destino
			vEnd = encontraVerticeMaisProxDoPonto(grafoDir, regis[indexRegistro2].x, regis[indexRegistro2].y);
			
			if (txt == NULL){
				aux = funcTxt(argc, argv);
				txt = fopen(aux, "w");
				funcFree(&aux);
			}

			Lista listCaminho = calculaMelhorCaminho(grafoDir, v0, vEnd);
			
			if(strcmp(textualOuPictorica, "p") == 0){
				Posic p;
				FILE *svgTemp;
				char *svgTempName = calloc(50, sizeof(char));
				svgTempName = funcSvgQry(argc, argv);
				strcat(svgTempName, sufixo);
				svgTemp = fopen(svgTempName, "w");
				writeSvg(&svgTemp, listCir, listRet, listSem, listQua, listTor, listHid, listCar);
				printSvgList(&svgTemp, listCar, printSvgCarro);
				fprintf(svgTemp, "<line x1=\"%f\" y1=\"%f\" x2=\"%f\" y2=\"%f\" stroke=\"%s\" stroke-width=\"5\"  />\n", getVerticePosicX(v0), getVerticePosicY(v0), regis[indexRegistro].x, regis[indexRegistro].y, cor);
				fprintf(svgTemp, "<line x1=\"%f\" y1=\"%f\" x2=\"%f\" y2=\"%f\" stroke=\"%s\" stroke-width=\"5\"  />\n", getVerticePosicX(vEnd), getVerticePosicY(vEnd), regis[indexRegistro2].x, regis[indexRegistro2].y, cor);
				for(p = getLast(listCaminho); p != NULL; p = getPrevious(p)){
					v0 = getObjt(p);
					p = getPrevious(p);
					if(p){
						vEnd = getObjt(p);	
						fprintf(svgTemp, "<line x1=\"%f\" y1=\"%f\" x2=\"%f\" y2=\"%f\" stroke=\"%s\" stroke-width=\"5\" />\n", getVerticePosicX(v0), getVerticePosicY(v0), getVerticePosicX(vEnd), getVerticePosicY(vEnd), cor);
					}
					p = getNext(p);
				}
				fprintf(svgTemp, "</svg>");
				rewind(svgTemp);
				fprintf(svgTemp, "<svg width=\"%f\" height=\"%f\">\n", *svgW, *svgH);
				fclose(svgTemp);
			}
			else {
				fprintf(txt, "#####################################\n");
				fprintf(txt, "Consulta melhor caminho: \n");
				Posic p;
				for(p = getLast(listCaminho); p != NULL; p = getPrevious(p)){
					v0 = getObjt(p);
					p = getPrevious(p);
					if(p){
						vEnd = getObjt(p);
						Aresta a = getVerticePreviousAresta(vEnd);	
						if(getVerticePosicX(v0) < getVerticePosicX(vEnd)){
							fprintf(txt, "Vire a esquerda e siga pela %s\n", getArestaNome(a));
						}
						else if(getVerticePosicX(v0) > getVerticePosicX(vEnd)){
							fprintf(txt, "Vire a direita e siga pela %s", getArestaNome(a));
						}
						else if(getVerticePosicY(v0) < getVerticePosicY(vEnd)){
							fprintf(txt, "Vire a cima e siga pela %s", getArestaNome(a));
						}
						else if(getVerticePosicY(v0) > getVerticePosicY(vEnd)){
							fprintf(txt, "Vire a baixo e siga pela %s", getArestaNome(a));
						}

						if(getArestaLEsq(a) != "#" && getArestaLDir(a) != "#"){
							fprintf(txt, ", localizada a direita da quadra %s e a esquerda da quadra %s.\n", getArestaLEsq(a), getArestaLDir(a));
						} 
						else if(getArestaLEsq(a) != "#"){
							fprintf(txt, ", localizada a direita da quadra %s.\n", getArestaLEsq(a));
						}
						else if(getArestaLDir(a) != "#"){
							fprintf(txt, ", a esquerda da quadra %s.\n", getArestaLDir(a));
						}
						else fprintf(txt, ".\n");
					}
					p = getNext(p);
				}
				fprintf(txt, "você chegou ao seu destino.\n");
			}
		}
		else if(strcmp(word, "sp?") == 0){ 
			char *idRegistro = calloc(50, sizeof(char));
			char *idRegistro2 = calloc(50, sizeof(char));
			char *cor = calloc(50, sizeof(char));
			char *textualOuPictorica = calloc(50, sizeof(char));
			char *sufixo = calloc(50, sizeof(char));
			char *distOuTempo = calloc(50, sizeof(char));
			char *cor2 = calloc(50,sizeof(char));

			sscanf(line, "%s %s %s %s %s %s %s", word, textualOuPictorica, sufixo, distOuTempo, idRegistro, idRegistro2, cor);

			int iteracao = 0, auxc;
			char *ptr;
			char *tempLine = calloc(1, sizeof(line));
			strcpy(tempLine, line);
			ptr = strtok(tempLine, " ");
			for(iteracao = 0; iteracao < 4; iteracao++){
				ptr = strtok(NULL, " ");
			}

			while(ptr[0] == 'R'){
				ptr = strtok(NULL, " ");
			}

			strcpy(cor, ptr);
			ptr = strtok(NULL, " ");
			strcpy(cor2, ptr);

			iteracao = 0;
			Vertice v0; //vertice inicial
			Vertice vEnd; //vertice destino
			Posic p;
			FILE *svgTemp;
			char *svgTempName = calloc(50, sizeof(char));
			svgTempName = funcSvgQry(argc, argv);
			strcat(svgTempName, sufixo);
			svgTemp = fopen(svgTempName, "w");
			writeSvg(&svgTemp, listCir, listRet, listSem, listQua, listTor, listHid, listCar);
			printSvgList(&svgTemp, listCar, printSvgCarro);
		    ptr = strtok( line, " " );
		    while( ptr != NULL ) {
		    	if(ptr[0] == 'R'){
			      	if(iteracao == 0){
				      	strcpy(idRegistro, ptr);
				      	ptr = strtok( NULL, " " );
				      	strcpy(idRegistro2, ptr);
				      	iteracao ++;
				    }
				    else{
				    	strcpy(idRegistro, idRegistro2);
				    	strcpy(idRegistro2, ptr);
				    }

					long indexRegistro = extrai_Index(idRegistro);
					long indexRegistro2 = extrai_Index(idRegistro2);

					v0 = encontraVerticeMaisProxDoPonto(grafoDir, regis[indexRegistro].x, regis[indexRegistro].y);

					vEnd = encontraVerticeMaisProxDoPonto(grafoDir, regis[indexRegistro2].x, regis[indexRegistro2].y);
					
					if (txt == NULL){
						aux = funcTxt(argc, argv);
						txt = fopen(aux, "w");
						funcFree(&aux);
					}

					resetGrafoInfo(grafoDir);

					Lista listCaminho = calculaMelhorCaminho(grafoDir, v0, vEnd);
					
					if(strcmp(textualOuPictorica, "p") == 0){
						int aux2 = auxc % 2;
						if(aux2 == 0){
							fprintf(svgTemp, "<line x1=\"%f\" y1=\"%f\" x2=\"%f\" y2=\"%f\" stroke=\"%s\" stroke-width=\"5\"  />\n", getVerticePosicX(v0), getVerticePosicY(v0), regis[indexRegistro].x, regis[indexRegistro].y, cor);
							fprintf(svgTemp, "<line x1=\"%f\" y1=\"%f\" x2=\"%f\" y2=\"%f\" stroke=\"%s\" stroke-width=\"5\"  />\n", getVerticePosicX(vEnd), getVerticePosicY(vEnd), regis[indexRegistro2].x, regis[indexRegistro2].y, cor);
						}
						else{
							fprintf(svgTemp, "<line x1=\"%f\" y1=\"%f\" x2=\"%f\" y2=\"%f\" stroke=\"%s\" stroke-width=\"5\"  />\n", getVerticePosicX(v0), getVerticePosicY(v0), regis[indexRegistro].x, regis[indexRegistro].y, cor2);
							fprintf(svgTemp, "<line x1=\"%f\" y1=\"%f\" x2=\"%f\" y2=\"%f\" stroke=\"%s\" stroke-width=\"5\"  />\n", getVerticePosicX(vEnd), getVerticePosicY(vEnd), regis[indexRegistro2].x, regis[indexRegistro2].y, cor2);
						}
						for(p = getLast(listCaminho); p != NULL; p = getPrevious(p)){
							v0 = getObjt(p);
							p = getPrevious(p);
							if(p){
								vEnd = getObjt(p);
								if(aux2 == 0)	
									fprintf(svgTemp, "<line x1=\"%f\" y1=\"%f\" x2=\"%f\" y2=\"%f\" stroke=\"%s\" stroke-width=\"5\" />\n", getVerticePosicX(v0), getVerticePosicY(v0), getVerticePosicX(vEnd), getVerticePosicY(vEnd), cor);
								else  
									fprintf(svgTemp, "<line x1=\"%f\" y1=\"%f\" x2=\"%f\" y2=\"%f\" stroke=\"%s\" stroke-width=\"5\" />\n", getVerticePosicX(v0), getVerticePosicY(v0), getVerticePosicX(vEnd), getVerticePosicY(vEnd), cor2);
							}
							p = getNext(p);
						}
					}
					else {
						fprintf(txt, "#####################################\n");
						fprintf(txt, "Consulta melhor caminho: \n");
						Posic p;
						for(p = getLast(listCaminho); p != NULL; p = getPrevious(p)){
							v0 = getObjt(p);
							p = getPrevious(p);
							if(p){
								vEnd = getObjt(p);
								Aresta a = getVerticePreviousAresta(vEnd);	
								if(getVerticePosicX(v0) < getVerticePosicX(vEnd)){
									fprintf(txt, "Vire a esquerda e siga pela %s\n", getArestaNome(a));
								}
								else if(getVerticePosicX(v0) > getVerticePosicX(vEnd)){
									fprintf(txt, "Vire a direita e siga pela %s", getArestaNome(a));
								}
								else if(getVerticePosicY(v0) < getVerticePosicY(vEnd)){
									fprintf(txt, "Vire a cima e siga pela %s", getArestaNome(a));
								}
								else if(getVerticePosicY(v0) > getVerticePosicY(vEnd)){
									fprintf(txt, "Vire a baixo e siga pela %s", getArestaNome(a));
								}

								if(getArestaLEsq(a) != "#" && getArestaLDir(a) != "#"){
									fprintf(txt, ", localizada a direita da quadra %s e a esquerda da quadra %s.\n", getArestaLEsq(a), getArestaLDir(a));
								} 
								else if(getArestaLEsq(a) != "#"){
									fprintf(txt, ", localizada a direita da quadra %s.\n", getArestaLEsq(a));
								}
								else if(getArestaLDir(a) != "#"){
									fprintf(txt, ", a esquerda da quadra %s.\n", getArestaLDir(a));
								}
								else fprintf(txt, ".\n");
							}
							p = getNext(p);
						}
						fprintf(txt, "você chegou ao seu destino.\n");
					}
		    	}
		    	auxc++;
		    	ptr = strtok(NULL, " "); 
			}
			fprintf(svgTemp, "</svg>");
			rewind(svgTemp);
			fprintf(svgTemp, "<svg width=\"%f\" height=\"%f\">\n", *svgW, *svgH);
			fclose(svgTemp);
		}

		else if(strcmp(word, "au") == 0){
			char *placa = calloc(50, sizeof(char));
			sscanf(line, "%s %s %lf %lf %lf %lf", word, placa, &x, &y, &width, &height);

			car1 = createCarro(width, height, x, y, placa, "green", "green");
			insert(listCar, car1);
		
			if ((getCarroX(car1) + getCarroWidth(car1)) > *svgW){
				*svgW = getCarroX(car1) + getCarroWidth(car1);
			}
			if ((getCarroY(car1) + getCarroHeight(car1)) > *svgH){
				*svgH = getCarroY(car1) + getCarroHeight(car1);
			}
		}
		else if(strcmp(word, "dc") == 0){ //Joao Vitor - montar este comando
			sscanf(line, "%s %s", word, cep);
			Posic p1, p2, p3, p4;
			Retangulo r1, r2;
			Carro c1, c2, c3;
			Lista col, copy;
			copy = createList();
			p1 = getFirst(listCar);
			for (i = 0; i<length(listCar); i++){
				insert(copy, getObjt(p1));
				p1 = getNext(p1);
			}
			char *svgSuf;
			FILE *sufixo;
			int f;
			double xmin, ymin, xmax, ymax;
			p1 = getFirst(copy);
			svgSuf = funcSvg(argc, argv, cep);
			sufixo = fopen(svgSuf, "w");
			fprintf(sufixo, "<svg width = \"%f\" height = \"%f\" >", *svgW + 20, *svgH + 20);
			printSvgList(&sufixo, listQua, printSvgQuadra);
			printSvgList(&sufixo, listCar, printSvgCarro);
			for (i = 0; i<length(copy); i++){
				c1 = getObjt(p1);
				p2 = getFirst(copy);
				col = createList();
				for (j = 0; j<length(copy); j++){
					c2 = getObjt(p2);
					if (c1 != c2){
						r1 = creatRetangulo(0, getCarroWidth(c1), getCarroHeight(c1), getCarroX(c1), getCarroY(c1), NULL, NULL);
						r2 = creatRetangulo(0, getCarroWidth(c2), getCarroHeight(c2), getCarroX(c2), getCarroY(c2), NULL, NULL);
						var = sobreposicaoRetanguloRetangulo(r1, r2);
						if (var == 1)
							insert(col, c2);
						if (r1 != NULL)
							free(r1);
						if (r2 != NULL)
							free(r2);
					}
					p2 = getNext(p2);
				}
				if (length(col) > 0){
					printf("%d\n", length(col));
					p3 = getFirst(col);
					xmax = 0;
					ymax = 0;
					ymin = getCarroY(c1);
					xmin = getCarroX(c1);
					for (f = 0; f<length(col); f++){
						c3 = getObjt(p3);
						r1 = creatRetangulo(0, getCarroWidth(c3), getCarroHeight(c3), getCarroX(c3), getCarroY(c3), NULL, NULL);
						cmpRet(r1, &xmax, &xmin, &ymax, &ymin);
						p3 = getNext(p3);
						free(r1);
					}
					printf("%f %f %f %f\n", xmax, ymax, xmin, ymin);
					r1 = creatRetangulo(0, (xmax-xmin + 4), (ymax-ymin + 4), xmin - 2, ymin - 2, "white", "red");
					fprintf(sufixo, "<rect x=\"%f\" y=\"%f\" width=\"%f\" height=\"%f\" fill=\"%s\" stroke=\"%s\" stroke-width=\"1\" fill-opacity = \"0.0\"/>\n",
					getRetanguloX(r1), getRetanguloY(r1), getRetanguloWidth(r1), getRetanguloHeight(r1), getRetanguloCorPreenchimento(r1), getRetanguloCorContorno(r1));
					free(r1);
				}
				p4 = p1;
				p1 = getNext(p1);
				remover(copy, p4);
				deleteListComplete(col, NULL);
			}
			deleteListComplete(copy, NULL);
			fprintf(sufixo, "</svg>\n");
		}
		else if(strcmp(word, "rau") == 0){ //Joao Vitor - montar este comando
			sscanf(line, "%s %s", word, cep);
			Posic p1;
			if (txt == NULL){
				aux = funcTxt(argc, argv);
				txt = fopen(aux, "a");
				funcFree(&aux);
			}
			p1 = searchObjCep(listCar, cep, getCarroPlaca);
			if (p1!= NULL){
				c1 = getObjt(p1);
				fprintf(txt, "RAU: Carro placa: %s, x: %f, y: %f\n", getCarroPlaca(c1), getCarroX(c1), getCarroY(c1));			
			}				
		} 
	}
	funcFree(&line);
	funcFree(&word);
	funcFree(&cor1);
	funcFree(&cor2);
	funcFree(&suf);
	funcFree(&corHP);
	funcFree(&corHC);
	funcFree(&corSP);
	funcFree(&corSC);
	funcFree(&corTP);
	funcFree(&corTC);
	funcFree(&complm);
	funcFree(&corQC);
	funcFree(&corQP);
	funcFree(&cep);
	funcFree(&tipo);
	funcFree(&face);
	funcFree(&cpf);
	funcFree(&cnpj);
	funcFree(&codt);
	funcFree(&tipo);
	fclose(entrada);
	funcFree(&testCEP);
	if (txt != NULL)
		fclose(txt);
}

void leituraVia(Hash ha, int argc, char *argv[], char *arqIn, double *svgH, double *svgW, FILE **svgMain, Lista listCir, Lista listRet, Lista listQua, Lista listSem, Lista listHid, Lista listTor, Lista listPessoa, Hash hashCpf_Cep, Hash hashCpf_Quadra, Hash hashCpf_DadosPessoa, Hash hashCep_Quadra, Hash hashCodt_Desc, kdTree kd_quadra, kdTree kd_hid, kdTree kd_sem, kdTree kd_torre, GrafoD grafoDir, registrador regis[10], Lista listCar){
	Posic p1 = NULL, p2 = NULL;
	FILE *entrada = NULL, *txt = NULL, *svg = NULL, *lixo = NULL;
	Circulo c1 = NULL, c2 = NULL;
	Retangulo r1 = NULL, r2 = NULL;
	Quadra q1 = NULL, q2 = NULL;
	Semaforo s1 = NULL;
	Torre t1 = NULL;
	Hidrante h1 = NULL;
	Estab estab1 = NULL;
	Pessoa pessoa1 = NULL;
	Endereco end1 = NULL;
	HashElement elementCpf_Quadra, elementCpf_DadosPessoa, elementCep_Quadra, elementCodt_Desc;
	char *line = NULL, *word = NULL, *cor1 = NULL, *cor2 = NULL, 
	*aux = NULL, *aux2 = NULL, *aux3 = NULL, *suf = NULL, *cep = NULL, *testCEP = NULL, *cpf = NULL, *cnpj = NULL, *codt = NULL, *tipo = NULL, *face = NULL, *complm = NULL,
	*corQP = NULL, *corQC = NULL, *corHP = NULL, *corHC = NULL, *corTP = NULL, *corTC = NULL, *corSP = NULL, *corSC = NULL;
	int i, j, var, tipo1, tipo2, id1, id2, num;
	double raio, x, y, height, width, value, xme, yme, xma, yma;
	tipo = (char*)malloc(sizeof(char)*20);
	complm = (char*)malloc(sizeof(char)*20);
	face = (char*)malloc(sizeof(char)*20);
	cep = (char*)malloc(sizeof(char)*20);
	cpf = (char*)malloc(sizeof(char)*20);
	cnpj = (char*)malloc(sizeof(char)*20);
	codt = (char*)malloc(sizeof(char)*20);
	line = (char*)malloc(sizeof(char)*200);
	word =(char*)malloc(sizeof(char)*30);
	cor1 = (char*)malloc(sizeof(char)*20);
	cor2 = (char*)malloc(sizeof(char)*20);
	suf = (char*)malloc(sizeof(char)*40);
	corQP = (char*)malloc(sizeof(char)*20);
	corQC = (char*)malloc(sizeof(char)*20);
	corHP = (char*)malloc(sizeof(char)*20);
	corHC = (char*)malloc(sizeof(char)*20);
	corSP = (char*)malloc(sizeof(char)*20);
	corSC = (char*)malloc(sizeof(char)*20);
	corTP = (char*)malloc(sizeof(char)*20);
	corTC = (char*)malloc(sizeof(char)*20);
	entrada = fopen(arqIn, "r");
	num= 0;
	if(entrada == NULL){
		printf("Error opening file.");
		return;
	}
	while(!feof(entrada)){
		fscanf(entrada, "%[^\n]\n", line);
		sscanf(line, "%s", word);
	if(strcmp(word, "v") == 0){
			char *idVertice = calloc(50, sizeof(char));
			sscanf(line, "%s %s %lf %lf", word, idVertice, &x, &y);
			Vertice v = createVertice(idVertice, x, y);
			insertVerticeGrafo(grafoDir, v);
		}
		else if(strcmp(word, "e") == 0){
			char *idVertice1, *idVertice2, *cep1, *cep2, *nome;
			idVertice1 = calloc(50, sizeof(char));
			idVertice2 = calloc(50, sizeof(char));
			cep1 = calloc(50, sizeof(char));
			cep2 = calloc(50, sizeof(char));
			nome = calloc(50, sizeof(char));
			double cmp, vm;
			sscanf(line, "%s %s %s %s %s %lf %lf %s", word, idVertice1, idVertice2, cep1, cep2, &cmp, &vm, nome);

			Lista lTest = getGrafoListaVertices(grafoDir);
			Vertice v;

			Aresta a = createAresta(idVertice1, idVertice2, cep1, cep2, cmp, vm, nome, grafoDir);
			
			Posic p;
			for(p = getFirst(lTest); p != NULL; p = getNext(p)){
				v = getObjt(p);
				if(strcmp(idVertice1, getVerticeId(v)) == 0){
					insertArestaVertice(v, a); //insere uma aresta a no vertice v
				}
			}
		}
	}
}


void leituraEC(int argc, char *argv[], char *arqIn, Hash hashCodt_Desc, Hash hashCep_Quadra){
	FILE *entrada = NULL;
	char *line = NULL, *word = NULL;
	char *aux = NULL, *aux2 = NULL, *aux3 = NULL, *aux4 = NULL, *aux5 = NULL, *aux6 = NULL,
		 *cnpj = NULL, *codt = NULL, *cep = NULL, *face = NULL, *nome = NULL, *tipo = NULL;
	int num;
	Quadra q1 = NULL;
	Estab estab1 = NULL; 
	HashElement elementCodt_Desc, elementCep_Quadra;
	Posic p1 = NULL;
	entrada = fopen(arqIn, "r");
	if(entrada == NULL){
		printf("Error opening file(-ec).");
		return;
	}
	line = (char*)malloc(sizeof(char)*200);
	word =(char*)malloc(sizeof(char)*30);
	aux =(char*)malloc(sizeof(char)*30);
	aux2 =(char*)malloc(sizeof(char)*30);
	aux3 =(char*)malloc(sizeof(char)*30);
	aux4 =(char*)malloc(sizeof(char)*30);
	aux5 =(char*)malloc(sizeof(char)*30);
	aux6 =(char*)malloc(sizeof(char)*30);
	while(!feof(entrada)){
		fscanf(entrada, "%[^\n]\n", line);
		sscanf(line, "%s", word);	
		if(strcmp(word, "t") == 0){
			sscanf(line, "%s %s %s", word, aux2, aux3);
			codt = malloc(sizeof(strlen(aux2) + 1));
			tipo = calloc(strlen(aux3), sizeof(char) + 1);
			strcpy(codt, aux2);
			strcpy(tipo, aux3);
			elementCodt_Desc = createHashElement(codt, tipo); //cria um struct {(String)codt x (String)tipo}
			addHash(hashCodt_Desc, elementCodt_Desc, codt); //adiciona essa struct à hash hashCodt_Desc
		}
		else if (strcmp(word, "e") == 0){
			sscanf(line, "%s %s %s %s %s %d %s", word, aux, aux2, aux3, aux4, &num, aux5);
			cnpj = calloc(strlen(aux) + 1, sizeof(char));
			codt = calloc(strlen(aux2) + 1, sizeof(char));
			cep = calloc(strlen(aux3) + 1, sizeof(char));
			face = calloc(strlen(aux4) + 1, sizeof(char));
			nome = calloc(strlen(aux5) + 1, sizeof(char));
			strcpy(cnpj, aux);
			strcpy(codt, aux2);
			strcpy(cep, aux3);
			strcpy(face, aux4);
			strcpy(nome, aux5);	
			elementCodt_Desc = searchHash(hashCodt_Desc, codt, getHashElementId); //retorna struct {Codt x Tipo} referente ao parametro "codt" dado
			q1 = searchHash(hashCep_Quadra, cep, getQuadraCep); //retorna struct {(string)cep x (Quadra)Quadra}
			if(elementCodt_Desc && q1){
				tipo = getHashElementKey(elementCodt_Desc); //extrai "Tipo" dessa struct 
				estab1 = (Estab)createEstab(cnpj, tipo, cep, face, num, nome); //cria estabelecimento comercial
				addQuadraEstab(q1, estab1); //adiciona um estabelec. Comercial à quadra
			}
			funcFree(&codt);
		}		
	}
	funcFree(&line);
	funcFree(&word);
	funcFree(&aux);
	funcFree(&aux2);
	funcFree(&aux3);
	funcFree(&aux4);
	funcFree(&aux5);
	funcFree(&aux6);
	fclose(entrada);
}

void leituraPM(int arc, char *argv[], char *arqIn, Lista listPessoa, Lista listQua, Hash hashCpf_Cep, Hash hashCpf_Quadra, Hash hashCpf_DadosPessoa){
	FILE *entrada = NULL;
	char *line = NULL, *word = NULL;
	char *aux = NULL, *aux2 = NULL, *aux3 = NULL, *aux4 = NULL, *aux5 = NULL,
		 *cpf = NULL, *nome = NULL, *sobrenome = NULL, *sexo = NULL, *nasc = NULL, *cep = NULL, *face = NULL, *complm = NULL;
	int num;
	HashElement elementCpf_Quadra = NULL, elementCpf_Cep = NULL, elementCpf_DadosPessoa = NULL;
	Posic i;
	Quadra q1 = NULL;
	Pessoa pessoa = NULL;
	Endereco end1 = NULL;
	line = (char*)malloc(sizeof(char)*200);
	word =(char*)malloc(sizeof(char)*50);
	aux =(char*)malloc(sizeof(char)*50);
	aux2 =(char*)malloc(sizeof(char)*50);
	aux3 =(char*)malloc(sizeof(char)*50);
	aux4 =(char*)malloc(sizeof(char)*50);
	aux5 =(char*)malloc(sizeof(char)*50);
	entrada = fopen(arqIn, "r");
	if(entrada == NULL){
		printf("Error opening file(-pm).");
		return;
	}
	while(!feof(entrada)){		
		fscanf(entrada, "%[^\n]\n", line);
		sscanf(line, "%s", word);
		if(strcmp(word, "p") == 0){
			sscanf(line, "%s %s %s %s %s %s", word, aux, aux2, aux3, aux4, aux5);
			cpf = calloc(strlen(aux)+1, sizeof(char));
			nome = calloc(strlen(aux2)+1, sizeof(char));
			sobrenome = calloc(strlen(aux3)+1, sizeof(char));
			sexo = (char*)malloc(sizeof(strlen(aux4)+10));
			nasc = calloc(strlen(aux5)+1, sizeof(char));
			strcpy(cpf, aux);
			strcpy(nome, aux2);
			strcpy(sobrenome, aux3);
			strcpy(sexo, aux4);
			strcpy(nasc, aux5);
			pessoa = createPessoa(cpf, nome, sobrenome, sexo, nasc);
			elementCpf_DadosPessoa = createHashElement(cpf, pessoa); //cria um struct {(String)cpf x (Pessoa)Pessoa}
			addHash(hashCpf_DadosPessoa, elementCpf_DadosPessoa, cpf); //adiciona essa struct na hash na posicao adequada
			insert(listPessoa, (Item)pessoa);
		}
		else if(strcmp(word, "m") == 0){
			sscanf(line, "%s %s %s %s %d %s", word, aux, aux2, aux3, &num, aux4);
			cpf = calloc((strlen(aux) +1), sizeof(char));		
			cep = (char*)malloc(sizeof(strlen(aux2)+ 1));
			face = (char*)malloc(sizeof(strlen(aux3)+ 1));
			complm = (char*)malloc(sizeof(strlen(aux4)+ 1));
			strcpy(cpf, aux);
			strcpy(cep, aux2);
			for(i = getFirst(listQua); i != NULL; i = getNext(i)){
				q1 = getObjt(i);
				if(strcmp(getQuadraCep(q1), cep) == 0){
					elementCpf_Quadra = createHashElement(cpf, q1); //cria um struct {(string)cpf x (Quadra)Quadra}
					addHash(hashCpf_Quadra, elementCpf_Quadra, cpf); //adiciona essa struct na hash na posicao adequada
				}
			}
			elementCpf_Cep = createHashElement(cpf, cep); //cria uma struct do tipo (String)cpf x (String)cep
			addHash(hashCpf_Cep, elementCpf_Cep, cpf); //adiciona essa struct na hashCpf_Cep
			strcpy(face, aux3);
			strcpy(complm, aux4);
			for(i = getFirst(listPessoa); i != NULL; i = getNext(i)){ //percorre a listaPessoa
				pessoa = getObjt(i); //retorna o struct pessoa da posicao atual da lista
				if(strcmp(getPessoaCpf(pessoa), cpf) == 0){
					end1 = createEndereco(cep, face, num, complm);
					setPessoaEndereco(pessoa, end1); //pessoa i possui cpf == parametro dado --> atualiza o endereco dela
					break;
				}
			}
		}

	}
	funcFree(&aux);
	funcFree(&aux2);
	funcFree(&aux3);
	funcFree(&aux4);
	funcFree(&aux5);
	funcFree(&line);	
	funcFree(&word);
	fclose(entrada);
}