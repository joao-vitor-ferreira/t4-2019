#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>
#include <limits.h>
#include <math.h>
#include <string.h>
#include "Lista.h"
#include "GrafoDirecionado.h"

typedef struct{
	Lista *vertices;
}grafoD;

double calculaRotaPontos(double x1, double y1, double x2, double y2, double vm){
	double calc = sqrt(pow(x2 - x1, 2) + pow(y2 - y1, 2));
	calc = calc * vm; //vel media
	return calc;
}

typedef struct {
	char *id;
	double x;
	double y;
	bool isOpen;
	struct vertice *previous;
	struct aresta *previousAresta;
	double bestRoute;
	Lista *arestas;
}vertice;

typedef struct {
	vertice *v1;
	vertice *v2;
	char *ldir; //quadra ao lado direito (hifen = nenhuma)
	char *lesq; //quadra ao lado esquerdo (hifen = nenhuma)
	double cmp; //comprimento da rua(aresta)
	double vm; //velocidade media na rua
	char *nome; //nome da rua
	bool interditado;
}aresta;

GrafoD createGrafo(){ //grafo possui vertices, que por sua vez possuem arestas(ou caminhos)
	grafoD *newGrafoD = malloc(sizeof(grafoD));
	newGrafoD->vertices = createList();
	return newGrafoD;
}

Vertice createVertice(char *id, double x, double y){
	vertice *newVertice = malloc(sizeof(vertice));
	newVertice->id = id;
	newVertice->x = x;
	newVertice->y = y;
	newVertice->arestas = createList();
	newVertice->isOpen = true;
	newVertice->previous = NULL;
	newVertice->bestRoute = LONG_MAX/2;
	newVertice->previousAresta = NULL;
	return newVertice;
}

Vertice getV1FromAresta(Aresta a){
	aresta *newAresta = a;
	return newAresta->v1;
}

Vertice getV2FromAresta(Aresta a){
	aresta *newAresta = a;
	return newAresta->v2;
}

double getVelMediaAresta(Aresta a){
	aresta *newAresta = a;
	return newAresta->vm;
}

Aresta createAresta(char *i, char *j, char *ldir, char *lesq, double cmp, double vm, char *nome, GrafoD grafoDir){
	aresta *newAresta = malloc(sizeof(aresta));
	GrafoD *newGrafoD = grafoDir;
	Vertice v;
	Posic p;
	int n = 0;
	for(p = getFirst(getGrafoListaVertices(grafoDir)); n < 2; p = getNext(p)){
		v = getObjt(p);
		if(strcmp(getVerticeId(v), i) == 0){
			newAresta->v1 = v;
			n++;
		}
		else if(strcmp(getVerticeId(v), j) == 0){
			newAresta->v2 = v;
			n++;
		}
	}
	newAresta->ldir = ldir;
	newAresta->lesq = lesq;
	newAresta->cmp = cmp;
	newAresta->vm = vm;
	newAresta->nome = nome;
	newAresta->interditado = false;
	return newAresta;
}

void resetGrafoInfo(GrafoD grafoDir){
	grafoD *newGrafoD = grafoDir;
	Posic p;
	Vertice verticeAtual;
	for(p = getFirst(getGrafoListaVertices(newGrafoD)); p != NULL; p = getNext(p)){
		verticeAtual = getObjt(p);
		if(verticeIsOpen(verticeAtual) == false){
			openVertice(verticeAtual);
		}
		if(getVerticePrevious(verticeAtual) != NULL){
			setVerticePrevious(verticeAtual, NULL);
		}
		if(getVerticeBestRoute(verticeAtual) != LONG_MAX/2){
			setVerticeBestRoute(verticeAtual, LONG_MAX/2);
		}
		if(getVerticePreviousAresta(verticeAtual) != NULL){
			setVerticePreviousAresta(verticeAtual, NULL);
		}
	}
}

Vertice encontraVerticeMaisProxDoPonto(GrafoD grafoDir, double x, double y){
	grafoD *newGrafoD = grafoDir;
	Posic p, p2;
	Vertice verticeAtual, verticeRetorno;
	double menorDist = LONG_MAX/2;
	double dist_Test;
		
	for(p = getFirst(getGrafoListaVertices(newGrafoD)); p != NULL; p = getNext(p)){
		
		verticeAtual = getObjt(p);

		dist_Test = calculaRotaPontos(getVerticePosicX(verticeAtual), getVerticePosicY(verticeAtual), x, y, 1);
		
		if(dist_Test < menorDist) {
			menorDist = dist_Test;
			p2 = getFirst(getVerticeListaArestas(verticeAtual));
			if(p2)
				verticeRetorno = verticeAtual;
		}
	}	
	return verticeRetorno;
}

bool interditado(Aresta a){
	aresta *newAresta = a;
	return newAresta->interditado;
}

Lista calculaMelhorCaminho(GrafoD grafoDir, Vertice v0, Vertice vEnd){
	grafoD *newGrafoD = grafoDir;
	setVerticePrevious(v0, NULL);
	setVerticeBestRoute(v0, 0);

	Vertice verticeTest, verticeAtual;
	Vertice v1, v2;
	Posic p, p2, p3;
	Aresta a;
	
	int n = 0, i = 0, j = 0;
	double routeTest;

	double menorRota;
	bool finished = false;
	while(!finished){
		menorRota = LONG_MAX / 2;
		for(p2 = getFirst(getGrafoListaVertices(grafoDir)); p2 != NULL; p2 = getNext(p2)){ //enquanto houver vertice aberto, verifica (algoritmo de Djikstra)
			verticeTest = getObjt(p2);

			if(verticeIsOpen(verticeTest) && getVerticeBestRoute(verticeTest) < menorRota) { //pega o vertice com a melhor estimativa atual
				menorRota = getVerticeBestRoute(verticeTest);
				verticeAtual = verticeTest;
			}
		}
		if(menorRota == LONG_MAX / 2){
			finished = true;
			break;
		}
		closeVertice(verticeAtual);	
		for(p = getFirst(getVerticeListaArestas(verticeAtual)); p != NULL; p = getNext(p)){ //verifica cada aresta do vertice atual
			a = getObjt(p);
			
			if(interditado(a)){
				continue;
			}
			v2 = getV2FromAresta(a);

			if(verticeIsOpen(v2)){
				if(i == 0){ //apenas na primeira iteracao		
					v1 = getV1FromAresta(a);
					i++;
				}

				routeTest = calculaRotaPontos(getVerticePosicX(v1), getVerticePosicY(v1), getVerticePosicX(v2), getVerticePosicY(v2), getVelMediaAresta(a));		
				routeTest = routeTest + getVerticeBestRoute(v1);
				if(routeTest < getVerticeBestRoute(v2)){ // rota de v1 a v2 melhor do que a anterior
					setVerticeBestRoute(v2, routeTest);
					setVerticePrevious(v2, v1);
				}
			}
		}
		i = 0;
	}

	Lista listCaminho = createList();
	verticeAtual = vEnd;
	while(verticeAtual != v0){
		insert(listCaminho, verticeAtual);
		n++;
		verticeAtual = getVerticePrevious(verticeAtual);
	}
	insert(listCaminho, v0);

	return listCaminho;
}

void insertVerticeGrafo(GrafoD grafoDir, Vertice vert){
	grafoD *newGrafoD = grafoDir;
	insert(newGrafoD->vertices, vert); 
	return;
}

void insertArestaVertice(Vertice v, Aresta a){
	vertice *newVertice = v;
	insert(newVertice->arestas, a); 
}

void openVertice(Vertice v){
	vertice *newVertice = v;
	newVertice->isOpen = true;
}

void closeVertice(Vertice v){
	vertice *newVertice = v;
	newVertice->isOpen = false;
}

void setVerticePrevious(Vertice v, Vertice vPrev){
	vertice *newVertice = v;
	newVertice->previous = vPrev;
}

void setVerticePreviousAresta(Vertice v, Aresta aPrev){
	vertice *newVertice = v;
	newVertice->previousAresta = aPrev;
}

Vertice getVerticePrevious(Vertice v){
	vertice *newVertice = v;
	return newVertice->previous;
}

Aresta getVerticePreviousAresta(Vertice v){
	vertice *newVertice = v;
	return newVertice->previousAresta;
}

void setVerticeBestRoute(Vertice v, double bestRoute){
	vertice *newVertice = v;
	newVertice->bestRoute = bestRoute;
}

Lista *getGrafoListaVertices(GrafoD grafoDir){
	grafoD *newGrafoD = grafoDir;
	return newGrafoD->vertices;
}

Lista *getVerticeListaArestas(Vertice v){
	vertice *newVertice = v;
	return newVertice->arestas;
}

char *getVerticeId(Vertice v){
	vertice *newVertice = v;
	return newVertice->id;
}

double getVerticePosicX(Vertice v){
	vertice *newVertice = v;
	return newVertice->x;
}

double getVerticePosicY(Vertice v){
	vertice *newVertice = v;
	return newVertice->y;
}

bool verticeIsOpen(Vertice v){
	vertice *newVertice = v;
	return newVertice->isOpen;
}

double getVerticeBestRoute(Vertice v){
	vertice *newVertice = v;
	return newVertice->bestRoute;
}

char *getArestaNome(Aresta a){
	aresta *newAresta = a;
	return newAresta->nome;
}

char *getArestaLEsq(Aresta a){
	aresta *newAresta = a;
	return newAresta->lesq;
}

char *getArestaLDir(Aresta a){
	aresta *newAresta = a;
	return newAresta->ldir;
}