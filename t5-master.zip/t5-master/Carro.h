#ifndef CARRO_H
#define CARRO_H

	typedef void *Carro;

Carro createCarro(double width, double height, double x, double y, char *placa, char *corPreenchimento, char *corContorno);
double getCarroWidth(Carro c);
char *getCarroPlaca(Carro c);
double getCarroHeight(Carro c);
double getCarroX(Carro c);
double getCarroY(Carro c);
char *getCarroCorPreenchimento(Carro c);
char *getCarroCorContorno(Carro c);
void freeCorCarro(Carro c);
#endif