#ifndef kdTree_h
#define kdTree_h
#include "Lista.h"
#include "Vector.h"

typedef void * itemKdTree;
typedef void * kdTree;
typedef void (*printarItemKdTree)(itemKdTree);
typedef int (*comparacaoKdTree)(itemKdTree, char *);

kdTree criarKdTree(void);

itemKdTree inserirItemKdTree(kdTree arvore, itemKdTree it, float x, float y);

itemKdTree buscarItemKdTree(kdTree arvore, char *id, comparacaoKdTree function);

itemKdTree deletarItemKdTree(kdTree arvore, itemKdTree it, float x, float y);

itemKdTree encontrarMinimo(kdTree arvore, int a);

Lista itensKdTreeRegiao(kdTree arvore, itemKdTree it, comparacaoKdTree function);

Lista kdTreeParaLista(kdTree arvore);

void printarKdTree(kdTree arvore, printarItemKdTree function);

Vector kdTreeToVector(kdTree kd);


#endif
