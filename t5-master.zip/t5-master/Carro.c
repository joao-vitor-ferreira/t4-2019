#include <stdio.h>
#include <stdlib.h>
#include "Carro.h"

typedef struct {
	double w;
	double h;
	double x;
	double y;
	char *placa;
	char *corPreenchimento;	
	char *corContorno;
}carro;

Carro createCarro(double width, double height, double x, double y, char *placa, char *corPreenchimento, char *corContorno){
	carro *newcarro;
	newcarro = (carro*)malloc(sizeof(carro));
	newcarro->placa = placa;
	newcarro->w = width;
	newcarro->h = height;
	newcarro->x = x;
	newcarro->y = y;
	newcarro->corPreenchimento = corPreenchimento;
	newcarro->corContorno = corContorno;
	return (Carro) newcarro;
}

char *getCarroPlaca(Carro c){
	carro *newCarro = (carro*)c;
	return newCarro->placa;
}

double getCarroWidth(Carro c){
	carro *newcarro = (carro*)c;
	return newcarro->w;
}

double getCarroHeight(Carro c){
	carro *newcarro = (carro*)c;
	return newcarro->h;
}

double getCarroX(Carro c){
	carro *newcarro = (carro*)c;
	return newcarro->x;
}

double getCarroY(Carro c){
	carro *newcarro = (carro*)c;
	return newcarro->y;
}

char *getCarroCorPreenchimento(Carro c){
	carro *newcarro = (carro*)c;
	return newcarro->corPreenchimento;
}

char *getCarroCorContorno(Carro c){
	carro *newcarro = (carro*)c;
	return newcarro->corContorno;
}

void freeCorCarro(Carro c){
	carro *newcarro = (carro*)c;
	if (newcarro->corContorno != NULL){
		free(newcarro->corContorno);
	}
	if (newcarro->corPreenchimento != NULL){
		free(newcarro->corPreenchimento);
	}
}