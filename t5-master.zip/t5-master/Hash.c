#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <math.h>
#include "Hash.h"
#include "Lista.h"

typedef struct {
    int size;
    Lista *vet;
}hash;

typedef struct{
    void *key; //elemento correspondente à id dada
    char *id; //identificacao
}hashElement;

Hash createHash(int TABLE_SIZE){
    hash *newHash;
    newHash = (hash*)malloc(sizeof(hash));
    newHash->vet = (Lista*)malloc(TABLE_SIZE * sizeof(Lista));
    newHash->size = TABLE_SIZE;
    Lista list;
    for(int i = 0; i<TABLE_SIZE; i++){
        list = createList();
        newHash->vet[i] = list;
    }
    return newHash; 
}

int functionHash(char *str, int table_size){
    int i, x;
    int a = 11;
    unsigned int h = 0;
    for(i = 0; str[i] != '\0'; i++){
        h = (a*h + str[i])/2;
    }
    return h%table_size;
}

void addHash(Hash ha, void *hashElement, char *id){
    hash *newHash = (hash*)ha;
    int key;
    key = functionHash(id, newHash->size);
    insert(newHash->vet[key], hashElement);
}

void deleteHashElement(Hash ha, char *id, ID func){
    hash *newHash = (hash*)ha;
    Posic p;
    int key = functionHash(id, newHash->size);
    if (length(newHash->vet[key]) == 0){
        return;
    } else {
        for(p = getFirst(newHash->vet[key]); p!=NULL; p = getNext(p)){
            if (strcmp(id, func(getObjt(p))) == 0)
                remover(newHash->vet[key], p);
        }
    }
}

void *searchHash(Hash ha, char *id, ID func){
    hash *newHash = (hash*)ha;
        Posic p;
        int key = functionHash(id, newHash->size);
        if (length(newHash->vet[key]) == 0){
            return NULL;
        } 
        else {
            for(p = getFirst(newHash->vet[key]); p!=NULL; p = getNext(p)){
                if (strcmp(id, func(getObjt(p))) == 0)
                    return getObjt(p);
            }  
        }
        return NULL;
}

HashElement createHashElement (char *id, void *key) {
    hashElement *newHashElement;
    newHashElement = (hashElement*)malloc(sizeof(hashElement));
    newHashElement->id = id;
    newHashElement->key = key;
    return (HashElement) newHashElement;
}

char *getHashElementId (HashElement h){
    hashElement *newHashElement = (hashElement*) h;
    return newHashElement->id;
}

void *getHashElementKey (HashElement h){
    hashElement *newHashElement = (hashElement*) h;
    return newHashElement->key;
}

void freeHashAll(Hash ha){
    hash *newHash = (hash*)ha;
    int size = newHash->size;
    for (int i = 0; i<size; i++){
        deleteListComplete(newHash->vet[i], NULL);
    }
    if (newHash->vet != NULL)
        free(newHash->vet);
    if (newHash != NULL)
        free(newHash);
}