#ifndef REGISTRADOR_H
#define REGISTRADOR_H

typedef struct {
	double x;
	double y;
}registrador;

#endif