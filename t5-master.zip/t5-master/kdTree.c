
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "kdTree.h"
#include "Vector.h"

struct Node {
    float pontosXY[2]; // 0 - x & 1 - y
    itemKdTree element;
    struct Node *esq, *dir;
};
typedef struct Node Node;

struct Tree { // 1o Node da kdTree
    Node *raiz;
};
typedef struct Tree Tree;


kdTree criarKdTree(void) {
    Tree *tree;
    tree=(Tree*) malloc(sizeof(Tree));
    tree->raiz=NULL;
    
    return (tree);
}

Node *inserirRecursivoKdTree(Node *arvore, Node *novoNode, int auxiliar) {
    int profundidade=auxiliar % 2;
    
    if (arvore==NULL) {
        return (novoNode);
    }
    if (arvore->pontosXY[profundidade]<=novoNode->pontosXY[profundidade]) {
        arvore->dir=inserirRecursivoKdTree(arvore->dir, novoNode, auxiliar+1);
    }
    else {
        arvore->esq=inserirRecursivoKdTree(arvore->esq, novoNode, auxiliar+1);
    }
    
    return (arvore);
}

itemKdTree inserirItemKdTree(kdTree arvore, itemKdTree it, float x, float y) {
    Tree *tree=(Tree*)arvore;
    Node *novoNode;
    
    novoNode=(Node*) malloc(sizeof(Node));
    novoNode->dir=NULL;
    novoNode->esq=NULL;
    novoNode->element=it;
    novoNode->pontosXY[0]=x;
    novoNode->pontosXY[1]=y;
    
    if (tree->raiz==NULL) {
        tree->raiz=novoNode;
    }
    else {
        inserirRecursivoKdTree(tree->raiz, novoNode, 0);
    }
    
    return (novoNode);
}

itemKdTree buscarRecursivoKdTree(Node *arvore, char *informacao, itemKdTree elemento, comparacaoKdTree function) {
    itemKdTree resultado=elemento;
    
    if (arvore!=NULL) {
        if (arvore->element!=NULL) {
            if (function(arvore->element,informacao)==1) {
                resultado=arvore->element;
            }
        }
        if (resultado==NULL) {
            resultado=buscarRecursivoKdTree(arvore->esq, informacao, resultado, function);
            resultado=buscarRecursivoKdTree(arvore->dir, informacao, resultado, function);
        }
    }
    
    return (resultado);
}

itemKdTree buscarItemKdTree(kdTree arvore, char *id, comparacaoKdTree function) {
    Tree *tree=(Tree*)arvore;
    itemKdTree *elemento=NULL;
    
    if (tree->raiz!=NULL) {
        elemento=buscarRecursivoKdTree(tree->raiz, id, NULL, function);
    }
    
    return (elemento);
}

itemKdTree itemMinimo(Node *node, Node *node2, Node *node3, int profundidade) {
    Node *elemento=node;
    if (node2!=NULL && node2->pontosXY[profundidade]<elemento->pontosXY[profundidade]) {
        elemento=node2;
    }
    if (node3!=NULL && node3->pontosXY[profundidade] < elemento->pontosXY[profundidade]) {
        elemento=node3;
    }
    return (elemento);
}

itemKdTree encontrarMinimoRecursivoKdTree(Node *node, int auxiliar, int a, itemKdTree elemento) {
    int profundidade=auxiliar % 2;
    
    if (node==NULL) {
        return (elemento);
    }
    if (profundidade==a) {
        if (node->esq==NULL) {
            return (node);
        }
        return encontrarMinimoRecursivoKdTree(node->esq, auxiliar+1, a, elemento);
    }
    
    return itemMinimo(node, encontrarMinimoRecursivoKdTree(node->esq, auxiliar+1, a, elemento), encontrarMinimoRecursivoKdTree(node->dir, auxiliar+1, a, elemento), a);
}


itemKdTree encontrarMinimo(kdTree arvore, int a) {
    Node *node=(Node*)arvore;
    itemKdTree elemento=NULL;
    
    if (node!=NULL) {
        elemento=encontrarMinimoRecursivoKdTree(node, a+1, a, NULL);
    }
    
    return (elemento);
}

itemKdTree deletarRecursivoKdTree(Node *arvore, itemKdTree it, itemKdTree *resultado, int auxiliar, float x, float y) {
    int profundidade=auxiliar % 2;
    itemKdTree node;
    Node *aux,*nodeAtual=arvore;
    
    if (nodeAtual==NULL) {
        return (NULL);
    }
    if (nodeAtual->element==it) {
        if (nodeAtual->dir!=NULL) {
            node=encontrarMinimo(nodeAtual->dir, profundidade);
            aux=(Node*)node;
            if (*resultado==NULL) {
                *resultado=nodeAtual->element;
            }
            nodeAtual->element=aux->element;
            nodeAtual->pontosXY[0]=aux->pontosXY[0];
            nodeAtual->pontosXY[1]=aux->pontosXY[1];
            nodeAtual->dir=deletarRecursivoKdTree(nodeAtual->dir, aux->element, resultado, auxiliar+1, aux->pontosXY[0], aux->pontosXY[1]);
        }
        else if (nodeAtual->esq!=NULL) {
            node=encontrarMinimo(nodeAtual->esq, profundidade);
            aux=(Node*)node;
            if (*resultado==NULL) {
                *resultado=nodeAtual->element;
            }
            nodeAtual->element=aux->element;
            nodeAtual->pontosXY[0]=aux->pontosXY[0];
            nodeAtual->pontosXY[1]=aux->pontosXY[1];
            nodeAtual->dir=deletarRecursivoKdTree(nodeAtual->esq, aux->element, resultado, auxiliar+1, aux->pontosXY[0], aux->pontosXY[1]);
            nodeAtual->esq=NULL;
        }
        else {
            if (*resultado==NULL) {
                *resultado=nodeAtual->element;
            }
            free(nodeAtual);
            nodeAtual=NULL;
            return (NULL);
        }
        return (nodeAtual);
    }
    
    if (profundidade==0) {
        if (x<nodeAtual->pontosXY[0]) {
            nodeAtual->esq=deletarRecursivoKdTree(nodeAtual->esq, it, resultado, auxiliar+1, x, y);
        }
        else {
            nodeAtual->dir=deletarRecursivoKdTree(nodeAtual->dir, it, resultado, auxiliar+1, x, y);
        }
    }
    else if (profundidade==1) {
        if (y<nodeAtual->pontosXY[1]) {
            nodeAtual->esq=deletarRecursivoKdTree(nodeAtual->esq, it, resultado, auxiliar+1, x, y);
        }
        else {
            nodeAtual->dir=deletarRecursivoKdTree(nodeAtual->dir, it, resultado, auxiliar+1, x, y);
        }
    }
    
    return (nodeAtual);
}

itemKdTree deletarItemKdTree(kdTree arvore, itemKdTree it, float x, float y) {
    Tree *tree=(Tree*)arvore;
    itemKdTree elemento=NULL;
    
    if (tree->raiz!=NULL) {
        deletarRecursivoKdTree(tree->raiz, it, &elemento, 0, x, y);
    }
    
    return (elemento);
}

Lista itensKdTreeRegiaoRecursivo(Node *node, Lista list, itemKdTree it, comparacaoKdTree function) {
    
    if (node==NULL) {
        return (list);
    }
    itensKdTreeRegiaoRecursivo(node->esq, list, it, function);
    itensKdTreeRegiaoRecursivo(node->dir, list, it, function);
    if (function(node->element, it)==1) {
        insert(list, node->element);
    }
    
    return (list);
}

Lista itensKdTreeRegiao(kdTree arvore, itemKdTree it, comparacaoKdTree function) {
    Tree *tree=(Tree*)arvore;
    Lista list = createList();
    if (tree->raiz!=NULL) {
        itensKdTreeRegiaoRecursivo(tree->raiz, list, it, function);
    }
    
    return (list);
}

Lista kdTreeParaListaRecursivo(Node *node, Lista list) {
    if (node==NULL) {
        return (list);
    }
    kdTreeParaListaRecursivo(node->esq, list);
    kdTreeParaListaRecursivo(node->dir, list);
    insert(list, node->element);
    
    return (list);
}

Lista kdTreeParaLista(kdTree arvore) {
    Tree *tree=(Tree*)arvore;
    Lista list=createList();
    if (tree->raiz!=NULL) {
        kdTreeParaListaRecursivo(tree->raiz, list);
    }
    return (list);
}

void printarRecursivoKdTree(Node *elemento, printarItemKdTree function) {
    
    if (elemento!=NULL) {
        printarRecursivoKdTree(elemento->esq, function);
        printarRecursivoKdTree(elemento->dir, function);
        function(elemento->element);
    }
    
    return;
}

void printarKdTree(kdTree arvore, printarItemKdTree function) {
    Tree *tree=(Tree*)arvore;
    if (tree->raiz!=NULL) {
        printarRecursivoKdTree(tree->raiz, function);
    }
    
    return;
}

/*int qntdRecKd(Node *node, int n){
    if (node == NULL)
        return n;
    n = qntdRecKd(node->esq, n);
    n = qntdRecKd(node->dir, n);
    n++;
    return n;
}

int qntdKdTree(kdTree kd){
    Tree *tree = (Tree*)kd;
    int n = 0;
    if (tree->raiz==NULL)
        return 0;
    else{
        n = qntdRecKd(tree->raiz, n);
    }
}
int kdToVetRec(Node *node, Vector vet, int n){
    Elemento e1;
    if (node == NULL)
        return vet; 
    n = kdToVetRec(node->esq, vet, n);
    n = kdToVetRec(node->dir, vet, n);
    addVector(vet, node->element, n);
    n++;
    return n;
}
Vector kdTreeToVector(kdTree kd){// na função se assume que na arvore haja ao menos um elemento
    Tree *tree = (Tree*)kd;
    Vector vet;
    vet = createVector(qntdKdTree(kd));
    kdToVetRec(tree->raiz, vet, 0);
    return vet;
}
*/