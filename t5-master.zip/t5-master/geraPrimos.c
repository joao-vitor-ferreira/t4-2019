#include <stdio.h>

void main(){
    FILE *arq;
    arq = fopen("listaDePrimos.txt", "w");
    int i, j, count;
    for (i = 2; i<=1000; i++){
        for(j = 1, count = 0; j<=i; j++){
            if (i%j == 0)
                count++;
        }
        if (count <= 2)
            fprintf(arq, "%d, ", i);
    }
    fprintf(arq, "-1");
}