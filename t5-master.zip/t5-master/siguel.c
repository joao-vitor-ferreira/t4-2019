#include <stdio.h>
#include <stdlib.h>
#include "Retangulo.h"
#include "Circulo.h"
#include "Comandos.h"
#include "CalculoCirculoRetangulo.h"
#include "Lista.h"
#include "Quadra.h"
#include "Semaforo.h"
#include "Torre.h"
#include "Hidrante.h"
#include "Svg.h"
#include "EstabelecimentoComercial.h"
#include "Hash.h"
#include "Pessoa.h"
#include "kdTree.h"
#include "GrafoDirecionado.h"
#include "Registrador.h"
#include "Carro.h"

int main (int argc, char **argv){
	Lista listCir, listRet, listQua, listSem, listHid, listTor, listPessoa, listCar;
	Hash hashCodt_Desc, hashCpf_Cep, hashCpf_Quadra, hashCpf_DadosPessoa, hashCep_Quadra;
	Hash ha;

	GrafoD grafoDir = createGrafo();

	listSem = createList();
	listTor = createList();
	listRet = createList();
	listCir = createList();
	listQua = createList();
	listHid = createList();
	listPessoa = createList(); //Cria lista de pessoas
	hashCodt_Desc = createHash(2000); //cria uma hashtable com espaco p/ 2000 posicoes
	hashCpf_Cep = createHash(5000); // cria uma hashtable com espaco p/ 5000 posicoes
	hashCpf_Quadra = createHash(5000); // cria uma hashtable com espaco p/ 5000 posicoes
	hashCep_Quadra = createHash(5000);
	hashCpf_DadosPessoa = createHash(10000); //cria uma hashtable com espaco p/ 10000 posicoes
	ha = createHash(2023);
	kdTree kd_quadra, kd_sem, kd_torre, kd_hid;
	kd_quadra = criarKdTree();
	kd_torre = criarKdTree();
	kd_sem = criarKdTree();
	kd_hid = criarKdTree();

	listCar = createList();
	registrador regist[10]; // cria registrador com 10 posicoes para manipulacao

	FILE *svgMain = NULL, *svgQry = NULL;
	int a, b;
	double  svgW = 0, svgH = 0;
	char *str, *str2, *str3, *str4;
	int num = 0;
	
	svgW = 0.0;
	svgH = 0.0;
	str = pegaParametro(argc, argv, "-o");
	if (str == NULL){
		printf("Diretório de saída não informado\n");
		return 0;
	} 
	str2 = pegaParametro(argc, argv, "-f");
	if (str == NULL){
		printf("Arquivo de entrada não informado\n");
		return 0;
	}
	str = colocaBarra(str);
	str3 = (char*)malloc(sizeof(char)*(strlen(str) + strlen(str2) + 1));
	strcpy(str3, str);
	b = 0;
	for(a = strlen(str); a<(strlen(str) + strlen(str2) -3); a++){
		str3[a] = str2[b];
		b++;
	}
	str3[a] = 's';
	a++;
	str3[a] = 'v';
	a++;
	str3[a] = 'g';
	a++;
	str3[a] = '\0';
	svgMain = fopen(str3, "w");
	if(svgMain == NULL){
		printf("Error opening file.");
		return 0;
	}
	fprintf(svgMain, "                                                                  ");
	if(str != NULL)
		free(str);
	str = funcIn(argc, argv, "-f");
	leitura(ha, argc, argv, str, &svgH, &svgW, &svgMain, listCir, listRet, listQua, listSem, listHid, listTor, listPessoa, hashCpf_Cep, hashCpf_Quadra, hashCpf_DadosPessoa, hashCep_Quadra, hashCodt_Desc, kd_quadra, kd_hid, kd_sem, kd_torre, grafoDir, regist, listCar);
	funcFree(&str);
	writeSvg(&svgMain, listCir, listRet, listSem, listQua, listTor, listHid, listCar);
	fprintf(svgMain, "</svg>");
	rewind(svgMain);
	svgH += 10.0;
	svgW += 10.0;
	fprintf(svgMain, "<svg width=\"%f\" height=\"%f\">\n", svgW, svgH);
	if (str != NULL)
		free(str);
	str = funcIn(argc, argv, "-ec"); // retorna "PathDeEntrada/nomeArquivoEC
	if (pegaParametro(argc, argv, "-ec") != NULL) { 
		leituraEC(argc, argv, str, hashCodt_Desc, hashCep_Quadra);
	}
	funcFree(&str);
	str = funcIn(argc, argv, "-pm"); // retorna "PathDeEntrada/nomeArquivoPM
	if (pegaParametro(argc, argv, "-pm") != NULL) { 
		leituraPM(argc, argv, str, listPessoa, listQua, hashCpf_Cep, hashCpf_Quadra, hashCpf_DadosPessoa);
	}
	funcFree(&str);
	str = funcIn(argc, argv, "-v"); // retorna "PathDeEntrada/nomeArquivoPM
	if (pegaParametro(argc, argv, "-v") != NULL) { 
		leituraVia(ha, argc, argv, str, &svgH, &svgW, &svgMain, listCir, listRet, listQua, listSem, listHid, listTor, listPessoa, hashCpf_Cep, hashCpf_Quadra, hashCpf_DadosPessoa, hashCep_Quadra, hashCodt_Desc, kd_quadra, kd_hid, kd_sem, kd_torre, grafoDir, regist, listCar);
	}
	funcFree(&str);
	str4 = pegaParametro(argc, argv, "-q");
	if (str4 != NULL){ //possui arquivo qry
		str = funcIn(argc, argv, "-q");
		funcFree(&str4);
		str4 = funcSvgQry(argc, argv);
		svgQry = fopen(str4, "w");
		funcFree(&str4);
		fprintf(svgQry, "                                                                          ");
		leitura(ha, argc, argv, str, &svgH, &svgW, &svgQry, listCir, listRet, listQua, listSem, listHid, listTor, listPessoa, hashCpf_Cep, hashCpf_Quadra, hashCpf_DadosPessoa, hashCep_Quadra, hashCodt_Desc, kd_quadra, kd_hid, kd_sem, kd_torre, grafoDir, regist, listCar);
		funcFree(&str);
		writeSvg(&svgQry, listCir, listRet, listSem, listQua, listTor, listHid, listCar);
		fprintf(svgQry, "</svg>");
		rewind(svgQry);
		svgH += 10.0;
		svgW += 10.0;
		fprintf(svgQry, "<svg width=\"%f\" height=\"%f\">\n", svgW, svgH);
		fclose(svgQry);
	}
	funcFree(&str4);	
	funcFree(&str2);
	funcFree(&str3);
	deleteListComplete(listRet, freeCor);
	deleteListComplete(listCir, freeCirculo);
	deleteListComplete(listTor, freeTorre);
	deleteListComplete(listSem, freeSemaforo);
	deleteListComplete(listQua, freeQuadra);
	deleteListComplete(listHid, freeHidrante);
	deleteListComplete(listPessoa, freePessoa);
	freeHashAll(hashCpf_Cep);
	freeHashAll(hashCodt_Desc);
	freeHashAll(hashCpf_Quadra);
	freeHashAll(hashCep_Quadra);
	freeHashAll(hashCpf_DadosPessoa);
	fclose(svgMain);
	freeHashAll(ha);
}
