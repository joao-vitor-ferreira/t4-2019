typedef struct{
	double x;
	double y;
}registrador;