#ifndef GRAFODIRECIONADO_H
#define GRAFODIRECIONADO_H
#include <stdbool.h>

	typedef void *Vertice;
	typedef void *Aresta;
	typedef void *GrafoD;

GrafoD createGrafo();
Vertice createVertice(char *id, double x, double y);
double calculaRotaPontos(double x1, double y1, double x2, double y2, double vm);
Aresta createAresta(char *i, char *j, char *ldir, char *lesq, double cmp, double vm, char *nome, GrafoD grafoDir);
void insertVerticeGrafo(GrafoD grafoDir, Vertice vert);
void insertArestaVertice(Vertice v, Aresta a);
void openVertice(Vertice v);
void closeVertice(Vertice v);
char *getVerticeId(Vertice v);
Lista *getGrafoListaVertices(GrafoD grafoDir);
Lista *getVerticeListaArestas(Vertice v);
char *getVerticeId(Vertice v);
double getVerticePosicX(Vertice v);
double getVerticePosicY(Vertice v);
bool verticeIsOpen(Vertice v);
void setVerticePrevious(Vertice v, Vertice vPrev);
void setVerticePreviousAresta(Vertice v, Aresta aPrev);
void setVerticeBestRoute(Vertice v, double smallestDist);
Vertice getVerticePrevious(Vertice v);
Aresta getVerticePreviousAresta(Vertice v);
double getVerticeBestRoute(Vertice v);
void resetGrafoInfo(GrafoD grafoDir);
Vertice encontraVerticeMaisProxDoPonto(GrafoD grafoDir, double x, double y);
Lista calculaMelhorCaminho(GrafoD grafoDir, Vertice v0, Vertice vEnd);
Vertice getV1FromAresta(Aresta a);
Vertice getV2FromAresta(Aresta a);
double getVelMediaAresta(Aresta a);
bool interditado(Aresta a);
char *getArestaNome(Aresta a);
char *getArestaLEsq(Aresta a);
char *getArestaLDir(Aresta a);


#endif